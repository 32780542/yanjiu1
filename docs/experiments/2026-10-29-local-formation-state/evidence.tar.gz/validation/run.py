"""Pair the new recorder against frozen P; compare all physical frames and trips."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
CURRENT = ROOT / "variants/phase5g_pure_formation"
OLD = ROOT / "tmp/common_pair_P_release"
OUT = ROOT / "tmp" / ("formation_state_validation_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
OUT.mkdir()
sys.path.insert(0, str(CURRENT))
from experiments.native_comparison import load_case


def read(path):
    return json.loads(path.read_bytes())


def run(package, label, road, mode):
    command = [sys.executable, "-B", str(package / "run_native_flow.py"), "--mode", mode,
               "--scenario", road, "--flow", "1500", "--seed", "6", "--duration", "60",
               "--max-time", "180", "--output-base", str(OUT / label)]
    completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, encoding="utf-8", check=True)
    (OUT / f"{label}_{road}_{mode}.stdout.log").write_text(completed.stdout, encoding="utf-8")
    (OUT / f"{label}_{road}_{mode}.stderr.log").write_text(completed.stderr, encoding="utf-8")
    return Path(json.loads(completed.stdout.splitlines()[-1])["run_dir"])


records = []
for road, modes in [("straight3", ("noa", "transform")), ("lane_drop", ("noa", "formation", "transform"))]:
    for mode in modes:
        before = run(OLD, "frozen_P", road, mode)
        after = run(CURRENT, "state_output", road, mode)
        old_input, new_input = read(before / "input.json"), read(after / "input.json")
        assert old_input["arrivals"] == new_input["arrivals"]
        assert old_input["physical"] == new_input["physical"]
        assert (before / "trips.json").read_bytes() == (after / "trips.json").read_bytes()
        with gzip.open(before / "positions.jsonl.gz", "rt", encoding="utf-8") as a, gzip.open(after / "positions.jsonl.gz", "rt", encoding="utf-8") as b:
            old_frames = [json.loads(line) for line in a]
            new_frames = [json.loads(line) for line in b]
        assert len(old_frames) == len(new_frames)
        for a, b in zip(old_frames, new_frames):
            assert a["time_s"] == b["time_s"] and a["states"] == b["states"]
            assert set(b["formation_states"]) == set(b["states"])
            assert all(type(value) is int and value in (0, 1) for value in b["formation_states"].values())
            if mode == "noa":
                assert not any(b["formation_states"].values())
        row, result = load_case(after), read(after / "result.json")
        assert row["performance_eligible"], row["audit_issues"]
        assert result["formation_state"]["peak_participants"] > 0 or mode == "noa"
        records.append(dict(scenario=road, mode=mode, baseline=str(before), current=str(after),
                            frames=len(new_frames), trips_byte_identical=True, physical_frames_identical=True,
                            requested=result["requested"], completed=result["completed"],
                            travel_time_s=result["mean_travel_time_s"], formation_state=result["formation_state"],
                            direct_state_audit_passed=True))
        print(json.dumps(records[-1]), flush=True)

source = read(Path(records[0]["current"]) / "input.json")["source_sha256"]
for name, expected in source.items():
    assert hashlib.sha256((CURRENT / name).read_bytes()).hexdigest() == expected
summary = dict(passed=True, source_sha256=source, case_pairs=5, baseline="frozen P 8d112d79",
               duration_s=60, flow_veh_h_lane=1500, seed=6, source_unchanged_during_run=True, cases=records,
               scope="Recording and statistics regression; no new efficiency or physical-formation claim")
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
(OUT / "manifest.json").write_text(json.dumps(dict(cases=[r["current"] for r in records]), indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(output=str(OUT), passed=True, physical_pairs=5)))
