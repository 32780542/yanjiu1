"""Verify the final staged P source, published report and implementation evidence."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from urllib.parse import unquote, urlsplit

ROOT = Path.cwd()
BASE = Path("docs/experiments/2026-10-29-four-flow-attribution")
EVIDENCE = BASE / "implementation_evidence"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def indexed(path):
    return subprocess.check_output(["git", "show", ":" + path.as_posix()])


def checked(path, expected=None):
    raw = path.read_bytes()
    assert indexed(path) == raw, ("index differs", str(path))
    value = digest(raw)
    if expected is not None:
        assert value == expected, (str(path), value, expected)
    return value


manifest = json.loads((EVIDENCE / "P_manifest.json").read_bytes())
source = {}
for relative, expected in manifest["source_sha256"].items():
    source[relative] = checked(Path("variants/phase5g_pure_formation") / relative, expected)
wrapper = checked(
    Path("variants/phase5g_pure_formation/run_flow_study.py"),
    "cf7a371677a08dd312ae904f410d26070452d464314b12b0a2b5943f0b2d1385",
)
archive = EVIDENCE / "P_implementation_evidence.tar.gz"
checked(archive, manifest["archive_sha256"])
with tarfile.open(fileobj=io.BytesIO(archive.read_bytes()), mode="r:gz") as stream:
    members = {m.name: stream.extractfile(m).read() for m in stream.getmembers() if m.isfile()}
assert set(members) == set(manifest["members"])
for name, raw in members.items():
    assert digest(raw) == manifest["members"][name], name
for label in ("core", "root_GUI"):
    result = json.loads(members[label + "/result.json"])
    assert result["returncode"] == 0, (label, result)
assert manifest["core_tests"] == 187 and manifest["subtests"] == 29
assert manifest["root_GUI_tests"] == 9

audit = json.loads((EVIDENCE / "P_report_public_audit.json").read_bytes())
report_path = Path(audit["report"])
report_hash = checked(report_path, audit["new_report_sha256"])
report = report_path.read_text(encoding="utf-8")
tables = re.findall(r"(?:^\|.*\|\r?\n?)+", report, re.MULTILINE)
assert len(tables) == audit["markdown_table_count"] == 14
assert "tmp/" not in report and "P_analysis/" not in report
links = []
for href in re.findall(r"\]\(([^)]+)\)", report):
    if urlsplit(href).scheme or href.startswith("#"):
        continue
    target = report_path.parent / unquote(href.split("#")[0])
    assert target.exists(), str(target)
    if target.is_file():
        indexed(target)
    links.append(href)
assert len(links) == 35
figure = json.loads(indexed(BASE / "figures/P.json"))
for relative, expected in figure["output_sha256"].items():
    checked(BASE / "figures" / relative, expected)
for relative, expected in figure["input_sha256"].items():
    checked(Path(relative), expected)
checked(EVIDENCE / "P_report_public_audit.json")
checked(EVIDENCE / "P_report_numeric_evidence.tar.gz", "1b97c5a9c7e1415b9374ba4ef1411137a2a45b0893497c57ebf45a938f3b4a23")
archival_files = 0
for folder in ("method_diagnostics", "event_diagnosis", "R_S_diagnostics", "implementation_evidence"):
    for path in sorted((BASE / folder).rglob("*")):
        if path.is_file():
            checked(path)
            archival_files += 1

# Unfrozen handoff prose follows normal Git line ending handling.
handoff_links = 0
for doc in (Path("README.md"), Path("docs/原生SUMO编队变换系统说明.md")):
    content = indexed(doc).decode("utf-8")
    for href in re.findall(r"\]\(([^)]+)\)", content):
        if urlsplit(href).scheme or href.startswith("#"):
            continue
        target = doc.parent / unquote(href.split("#")[0])
        assert target.exists(), (str(doc), str(target))
        handoff_links += 1
    assert "正在独立目录检验" not in content
subprocess.run(["git", "diff", "--cached", "--check"], check=True)
result = dict(
    passed=True,
    production_six_sources=source,
    wrapper_sha256=wrapper,
    implementation_archive_members=len(members),
    recorded_core_tests=187,
    recorded_subtests=29,
    recorded_root_GUI_tests=9,
    recorded_test_operation_returncodes_zero=True,
    report_sha256=report_hash,
    report_tables=14,
    published_report_links=35,
    current_handoff_links=handoff_links,
    figure_files_checked=2,
    archival_files_byte_checked=archival_files,
    frozen_index_bytes_identical=True,
    staged_whitespace_check=True,
    scientific_acceptance="not_passed",
    simulation_rerun=False,
    metrics_recomputed=False,
)
(ROOT / "tmp/P_final_publication_verification.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(result, ensure_ascii=False))
