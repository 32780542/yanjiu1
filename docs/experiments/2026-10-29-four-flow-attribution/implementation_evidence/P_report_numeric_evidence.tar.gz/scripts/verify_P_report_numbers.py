"""Independent frozen-source checks for the newly written P acceptance report."""
import csv
import gzip
import hashlib
import json
import re
from pathlib import Path

R = Path(__file__).resolve().parents[1]
B = R / "docs/experiments/2026-10-29-four-flow-attribution"
P, C = B / "portable_P", B / "portable_C1_P"
REPORT = R / "docs/2026-10-29-P独立验收报告.md"
AUDIT = R / "tmp/P_report_audit.json"
a = json.loads(AUDIT.read_text(encoding="utf-8"))
text = REPORT.read_text(encoding="utf-8")
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(REPORT.read_bytes()) == a["report_sha256"]
for relative, record in a["sources"].items():
    raw = (R / relative).read_bytes()
    assert len(raw) == record["bytes"] and sha(raw) == record["sha256"], relative
    if "decoded_sha256" in record:
        assert sha(gzip.decompress(raw)) == record["decoded_sha256"], relative

def gz(path):
    return json.loads(gzip.decompress(path.read_bytes()))

def csvr(path):
    return list(csv.DictReader(path.read_text(encoding="utf-8-sig").splitlines()))

def fmt(v, d=6, signed=False):
    return "—" if v is None else format(v, ("+" if signed else "") + f".{d}f")

def eq_mean(values):
    assert len(values) == 5
    return sum(values) / 5

blocks = re.findall(r"(?m)^\|.+(?:\n\|.+)+", text)
assert len(blocks) == len(a["table_values"]) == 14
tables = {}
for block, expected in zip(blocks, a["table_values"]):
    parsed = [[s.strip() for s in line.strip().strip("|").split("|")] for line in block.splitlines()]
    assert parsed[0] == expected["columns"], expected["table"]
    assert parsed[2:] == [[str(v) for v in row] for row in expected["displayed_rows"]], expected["table"]
    tables[expected["table"]] = parsed[2:]

attr = gz(P / "data/attribution_summary.json.gz")
ns = {q: gz(P / f"data/native_flow_{q}.json.gz")["runs"] for q in (500, 750, 1000, 1500)}
cr = csvr(C / "tables/flow_means.csv")
cp = csvr(C / "tables/pairs.csv")
cn = [gz(p)["native"] for p in (C / "data/case_evidence").glob("*.gz")]
checks = 0
for i, q in enumerate((500, 750, 1000, 1500)):
    n = {mode: sorted([x for x in ns[q] if x["scenario"] == "lane_drop" and x["mode"] == mode], key=lambda x: x["seed"]) for mode in ("noa", "formation", "transform")}
    r = tables["travel_and_DID"][i]
    for j, mode in enumerate(("noa", "formation", "transform"), start=1):
        assert r[j] == fmt(eq_mean([x["mean_travel_time_s"] for x in n[mode]]))
    ar = [x for x in attr["attributions"] if x["flow_veh_h_lane"] == q]
    assert r[5] == fmt(eq_mean([x["reduction_mean_segment_640_1100_s"] for x in ar]), signed=True)
    assert r[6] == fmt(eq_mean([x["reduction_mean_travel_time_s"] for x in ar]), signed=True)
    for j, mode in enumerate(("noa", "formation", "transform")):
        run = n[mode]
        row_index = 3 * i + j
        assert tables["fuel_low_speed_flow"][row_index][2] == fmt(eq_mean([x["fuel_g_per_km"] for x in run]), 3)
        for zone in ("upstream", "downstream"):
            row = tables[f"{zone}_quality"][row_index]
            assert row[2] == fmt(100 * eq_mean([x[f"{zone}_formation_participation_rate"] for x in run]), 4)
            assert row[3] == fmt(100 * eq_mean([x[f"{zone}_stable_participation_rate"] for x in run]), 4)
            size = [x[f"{zone}_mean_multilayer_size"] for x in run if x[f"{zone}_mean_multilayer_size"] is not None]
            assert row[4] == fmt(sum(size) / len(size) if size else None, 4) + f"（n={len(size)}）"
            assert row[5] == " / ".join("—" if x[f"{zone}_peak_multilayer_size"] is None else str(x[f"{zone}_peak_multilayer_size"]) for x in run)
        relation = tables["relations"][row_index]
        assert relation[2:] == [str(sum(x[f"{zone}_{field}"] for x in run)) for zone in ("upstream", "downstream") for field in ("internal_relation_breaks", "boundary_censored_relations")]
        rec = gz(P / f"data/recovery_flow_{q}.json.gz")["runs"]
        rr = [x for x in rec if x["scenario"] == "lane_drop" and x["mode"] == mode]
        all_ = [v for x in rr for v in x["per_vehicle"]]
        prior = [v for v in all_ if v["upstream_formed"]]
        ev = [v["delay_s"] for v in prior if v["delay_s"] is not None]
        ae = [v for v in all_ if v["delay_s"] is not None]
        row = tables["recovery"][row_index]
        assert row[2:] == [f"{len(ae)}/{len(all_)}", str(len(all_) - len(ae)), f"{len(ev)}/{len(prior)}", str(len(prior) - len(ev)), fmt(sum(ev) / len(ev) if ev else None, 4)]
        checks += 1
    paired = [x for x in cp if float(x["flow_veh_h_lane"]) == q]
    assert len(paired) == 5 and all(x["cooperative_parameters_sha256"] == x["P_parameters_sha256"] for x in paired)
    c = sorted([x for x in cn if any(y["cooperative_case_dir"] == x["case_dir"] for y in paired)], key=lambda x: x["seed"])
    assert tables["C1_P_comparison"][i][1] == fmt(eq_mean([x["mean_travel_time_s"] for x in c]))
    assert tables["C1_P_comparison"][i][3] == fmt(eq_mean([float(x["cooperative_mean_travel_time_s"]) - float(x["P_transform_mean_travel_time_s"]) for x in paired]), signed=True)
    assert tables["C1_P_comparison"][i][7] == fmt(eq_mean([x["fuel_g_per_km"] for x in c]), 3)
    for k, zone in enumerate(("upstream", "downstream")):
        row = tables["C1_P_participation"][2 * i + k]
        size = [x[f"{zone}_mean_multilayer_size"] for x in c if x[f"{zone}_mean_multilayer_size"] is not None]
        assert row[2:5] == [fmt(100 * eq_mean([x[f"{zone}_formation_participation_rate"] for x in c]), 4), fmt(100 * eq_mean([x[f"{zone}_stable_participation_rate"] for x in c]), 4), fmt(sum(size) / len(size) if size else None, 4) + f"（n={len(size)}）"]
        assert row[5] == " / ".join("—" if x[f"{zone}_peak_multilayer_size"] is None else str(x[f"{zone}_peak_multilayer_size"]) for x in c)
    assert tables["C1_P_relations"][i][1:] == [str(sum(x[f"{zone}_{field}"] for x in c)) for zone in ("upstream", "downstream") for field in ("internal_relation_breaks", "boundary_censored_relations")]

for i, seed in enumerate((6, 7, 8, 9, 10)):
    no, p = [next(x for x in ns[1500] if x["seed"] == seed and x["scenario"] == "lane_drop" and x["mode"] == mode)["mean_travel_time_s"] for mode in ("noa", "transform")]
    assert tables["1500_seed_pairs"][i] == [str(seed), fmt(no), fmt(p), fmt(p - no, signed=True)]
links = re.findall(r"\]\(([^)]+)\)", text)
assert all((REPORT.parent / link).exists() for link in links)
assert (200 - (6 * 30 + 15)) / 28.8 < 1
assert "0.17" in text and "640 米区域 PP 仍低" in text
assert all(token in text for token in ("种子 1–5", "不与本批新种子合并平均", "Cai", "原始、同工况实测数据", "187", "29 个子测试", "9 项根 GUI"))
result = dict(passed=True, report_sha256=a["report_sha256"], source_files_checked=len(a["sources"]), markdown_tables_checked=len(tables), P_mode_flow_cells_checked=checks, P_1500_seed_pairs_checked=5, C1_P_raw_parameter_pairs_checked=len(cp), links_checked=len(links), missing_links=[], existing_metrics_only=True)
a["independent_report_verification"] = result
AUDIT.write_text(json.dumps(a, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
print(json.dumps(result, ensure_ascii=False))
