"""Read frozen evidence; write only the new P report and its numerical audit."""
import csv
import gzip
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STUDY = ROOT / "docs/experiments/2026-10-29-four-flow-attribution"
P = STUDY / "portable_P"
C = STUDY / "portable_C1_P"
OUT = ROOT / "docs/2026-10-29-P独立验收报告.md"
AUDIT = ROOT / "tmp/P_report_audit.json"
FLOWS = (500, 750, 1000, 1500)
MODES = ("noa", "formation", "transform")
LABEL = {"noa": "NOA", "formation": "F", "transform": "P"}
SOURCES = {}
CELLS = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    data = path.read_bytes()
    SOURCES[path.relative_to(ROOT).as_posix()] = dict(bytes=len(data), sha256=sha(data))
    return data


def j(path):
    data = read(path)
    if path.suffix == ".gz":
        data = gzip.decompress(data)
        SOURCES[path.relative_to(ROOT).as_posix()]["decoded_sha256"] = sha(data)
    return json.loads(data.decode("utf-8-sig"))


def rows(path):
    return list(csv.DictReader(read(path).decode("utf-8-sig").splitlines()))


def f(value, digits=6, signed=False):
    if value is None or value == "":
        return "—"
    return format(float(value), ("+" if signed else "") + f".{digits}f")


def pct(value):
    return f(100 * float(value), 4)


def table(name, headings, data, exact=None):
    if exact is not None:
        # Exact input files are hash-bound separately; avoid duplicating whole
        # evaluator records just to audit a few displayed cells.
        CELLS.append(dict(table=name, columns=headings, displayed_rows=data))
    return "\n".join(["| " + " | ".join(headings) + " |", "| " + " | ".join(["---"] * len(headings)) + " |"] + ["| " + " | ".join(map(str, row)) + " |" for row in data])


def by(rows_, flow, mode):
    return next(r for r in rows_ if int(float(r["flow_veh_h_lane"])) == flow and r["mode"] == mode)


def cohort_stats(runs, mode, prior=False):
    selected = [r for r in runs if r["scenario"] == "lane_drop" and r["mode"] == mode]
    assert len(selected) == 5
    vr = [v for r in selected for v in r["per_vehicle"] if not prior or v["upstream_formed"]]
    observed = [v["delay_s"] for v in vr if v["delay_s"] is not None]
    stats = dict(subjects=len(vr), recovered=len(observed), censored=len(vr) - len(observed),
                 conditional_mean_delay_s=sum(observed) / len(observed) if observed else None)
    summaries = [r["upstream_formed"] if prior else r for r in selected]
    for key in ("subjects", "recovered", "censored"):
        assert stats[key] == sum(r[key] for r in summaries)
    if observed:
        weighted = sum(r["conditional_mean_delay_s"] * r["recovered"] for r in summaries if r["recovered"]) / len(observed)
        assert abs(weighted - stats["conditional_mean_delay_s"]) < 1e-10
    return stats


before = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for base in (P, C) for p in base.rglob("*") if p.is_file()}
traffic = rows(P / "tables/traffic_and_attribution.csv")
quality = rows(P / "tables/formation_quality.csv")
straight = rows(P / "tables/straight_controls.csv")
recovery_table = rows(P / "tables/recovery_counts.csv")
definitions = j(P / "tables/column_definitions.json")
attrs = j(P / "data/attribution_summary.json.gz")
natives = {q: j(P / f"data/native_flow_{q}.json.gz") for q in FLOWS}
recoveries = {q: j(P / f"data/recovery_flow_{q}.json.gz") for q in FLOWS}
cr = rows(C / "tables/flow_means.csv")
cpairs = rows(C / "tables/pairs.csv")
cruns = rows(C / "tables/runs.csv")
crecovery = j(C / "data/recovery_summary.json.gz")
cnative = [j(path)["native"] for path in sorted((C / "data/case_evidence").glob("*.json.gz"))]
c_source = j(C / "provenance/freeze.json")
protocol = j(P / "provenance/protocol.json")
p_verify = j(P / "independent_verification.json")
c_verify = j(C / "independent_verification.json")
integration = j(ROOT / "tmp/P_main_integration_evidence.json")
original_p1500_pairs = rows(STUDY / "P_analysis/flow_1500/native_comparison/pairs.csv")
original_p1500_runs = rows(STUDY / "P_analysis/flow_1500/native_comparison/runs.csv")
original_results = rows(STUDY / "P_analysis/four_flow_results.csv")
read(STUDY / "P_protocol.md")
for name in ("纯规则编队系统说明.md", "原生SUMO编队变换系统说明.md", "2026-10-29-MATLAB车辆控制调用链核查.md", "2026-10-29-四流量瓶颈归因报告.md"):
    read(ROOT / "docs" / name)

assert protocol["seeds"] == [6, 7, 8, 9, 10]
assert protocol["flows"] == [500.0, 750.0, 1000.0, 1500.0]
assert protocol["jobs"] == 4 and protocol["duration_s"] == 600 and protocol["max_time_s"] == 900
assert len(attrs["runs"]) == 100 and not attrs["excluded_cases"]
assert all(r["attribution_eligible"] for r in attrs["runs"])
assert sum(r["requested"] for r in attrs["runs"]) == 48060
assert len(cpairs) == len(cruns) == 20
assert {int(r["seed"]) for r in cpairs} == {6, 7, 8, 9, 10}
assert all(r["pair_eligible"] == "True" and r["raw_parameter_sha256_equal"] == "True" and r["cooperative_parameters_sha256"] == r["P_parameters_sha256"] for r in cpairs)
assert p_verify["passed"] and c_verify["passed"] and c_verify["requests"] == 9612
assert c_verify["ordinary_overtake_actions"] == 0
assert protocol["source_sha256"]["noa/native_rules.py"] == "8d112d79dce42b68fc4aba986aa52b5241c3ee4e8b6d8061cd04b80bcdb75864"

did = {q: next(r for r in attrs["attribution_means"] if int(r["flow_veh_h_lane"]) == q) for q in FLOWS}
first_rows = []
main_rows = []
control_rows = []
for q in FLOWS:
    nr, fr, pr = [by(traffic, q, mode) for mode in MODES]
    first_rows.append([q, f(nr["drop_TT_s"]), f(fr["drop_TT_s"]), f(pr["drop_TT_s"]), f(float(pr["drop_TT_s"]) - float(nr["drop_TT_s"]), signed=True), f(did[q]["reduction_mean_segment_640_1100_s_mean"], signed=True), f(did[q]["reduction_mean_travel_time_s_mean"], signed=True)])
    main_rows.append([q] + [f(r["drop_main_640_1100_s"]) for r in (nr, fr, pr)] + [f(nr["main_drop_minus_straight_s"]), f(pr["main_drop_minus_straight_s"])])
    ns, ps = by(straight, q, "noa"), by(straight, q, "transform")
    control_rows.append([q, f(ns["TT_s"]), f(ps["TT_s"]), f(float(ps["TT_s"]) - float(ns["TT_s"]), signed=True), f(did[q]["reduction_mean_segment_100_600_s_mean"], signed=True)])

paired1500 = []
for seed in range(6, 11):
    nr, pr = [next(r for r in natives[1500]["runs"] if r["seed"] == seed and r["scenario"] == "lane_drop" and r["mode"] == mode) for mode in ("noa", "transform")]
    delta = pr["mean_travel_time_s"] - nr["mean_travel_time_s"]
    original = next(r for r in original_p1500_pairs if int(r["seed"]) == seed and r["scenario"] == "lane_drop" and r["candidate_mode"] == "transform")
    assert abs(delta - float(original["delta_mean_travel_time_s"])) < 1e-12
    for mode, record in (("noa", nr), ("transform", pr)):
        raw = next(r for r in original_p1500_runs if int(r["seed"]) == seed and r["scenario"] == "lane_drop" and r["mode"] == mode)
        assert abs(float(raw["mean_travel_time_s"]) - record["mean_travel_time_s"]) < 1e-12
    paired1500.append(dict(seed=seed, NOA_TT_s=nr["mean_travel_time_s"], P_TT_s=pr["mean_travel_time_s"], P_minus_NOA_TT_s=delta))

traffic_rows = [[r["flow_veh_h_lane"], LABEL[r["mode"]], f(r["drop_fuel_g_km"], 3), f(r["region_low_speed_vehicle_s"], 2), pct(r["region_low_speed_fraction"]), f(r["region_window_speed_mps"], 3), f(r["flow_1000m_veh_h"], 2)] for r in traffic]
quality_rows = {}
for region in ("upstream", "downstream"):
    quality_rows[region] = []
    for r in quality:
        value = r[f"{region}_mean_multilayer_size_mean"]
        n = r[f"{region}_mean_multilayer_size_n"]
        peaks = json.loads(r[f"{region}_peak_by_seed"])
        quality_rows[region].append([r["flow_veh_h_lane"], LABEL[r["mode"]], pct(r[f"{region}_formation_participation_rate_mean"]), pct(r[f"{region}_stable_participation_rate_mean"]), f(value, 4) + f"（n={n}）", " / ".join("—" if x is None else str(x) for x in peaks)])

relations = []
relation_rows = []
for q in FLOWS:
    for mode in MODES:
        selected = [r for r in natives[q]["runs"] if r["scenario"] == "lane_drop" and r["mode"] == mode]
        record = dict(flow=q, mode=mode, seeds=5)
        for region in ("upstream", "downstream"):
            for field in ("internal_relation_breaks", "boundary_censored_relations"):
                record[f"{region}_{field}"] = sum(r[f"{region}_{field}"] for r in selected)
        relations.append(record)
        relation_rows.append([q, LABEL[mode]] + [record[k] for k in ("upstream_internal_relation_breaks", "upstream_boundary_censored_relations", "downstream_internal_relation_breaks", "downstream_boundary_censored_relations")])

rec_stats = []
rec_rows = []
for q in FLOWS:
    for mode in MODES:
        all_ = cohort_stats(recoveries[q]["runs"], mode)
        prior = cohort_stats(recoveries[q]["runs"], mode, True)
        row = by(recovery_table, q, mode)
        assert all_["subjects"] == int(row["all_adjusting_subjects"])
        assert prior["recovered"] == int(row["upstream_formed_recovered"])
        rec_stats.append(dict(flow=q, mode=mode, all_adjusting=all_, upstream_formed=prior))
        rec_rows.append([q, LABEL[mode], f'{all_["recovered"]}/{all_["subjects"]}', all_["censored"], f'{prior["recovered"]}/{prior["subjects"]}', prior["censored"], f(prior["conditional_mean_delay_s"], 4)])

c_rows = []
c_quality_rows = []
c_recovery = []
c_recovery_rows = []
c_window_rows = []
c_relation_rows = []
for q in FLOWS:
    r = next(r for r in cr if int(float(r["flow_veh_h_lane"])) == q)
    c_rows.append([q, f(r["cooperative_mean_travel_time_s_mean"]), f(r["P_transform_mean_travel_time_s_mean"]), f(r["cooperative_minus_P_mean_travel_time_s_mean"], signed=True), f(r["P_incremental_reduction_over_cooperative_mean_segment_640_1100_s_mean"], signed=True), f(r["cooperative_region_low_speed_vehicle_s_mean"], 2), f(r["P_transform_region_low_speed_vehicle_s_mean"], 2), f(r["cooperative_fuel_g_per_km_mean"], 3), f(r["P_transform_fuel_g_per_km_mean"], 3)])
    selected = [x for x in cnative if any(y["cooperative_case_dir"] == x["case_dir"] and int(float(y["flow_veh_h_lane"])) == q for y in cpairs)]
    selected.sort(key=lambda x: x["seed"])
    assert [x["seed"] for x in selected] == [6, 7, 8, 9, 10]
    for region, region_label in (("upstream", "上游"), ("downstream", "下游")):
        defined = [x[f"{region}_mean_multilayer_size"] for x in selected if x[f"{region}_mean_multilayer_size"] is not None]
        cm = sum(defined) / len(defined) if defined else None
        peaks = [x[f"{region}_peak_multilayer_size"] for x in selected]
        c_quality_rows.append([q, region_label, pct(r[f"cooperative_{region}_formation_participation_rate_mean"]), pct(r[f"cooperative_{region}_stable_participation_rate_mean"]), f(cm, 4) + f"（n={len(defined)}）", " / ".join("—" if x is None else str(x) for x in peaks)])
    c_relation_rows.append([q] + [sum(x[f"{region}_{field}"] for x in selected) for region in ("upstream", "downstream") for field in ("internal_relation_breaks", "boundary_censored_relations")])
    c_window_rows.append([q, f(r["cooperative_region_mean_speed_mps_mean"], 3), pct(r["cooperative_region_low_speed_fraction_mean"]), f(r["cooperative_flow_1000m_veh_h_mean"], 2)])
    rr = [x for x in crecovery["runs"] if any(y["cooperative_case_dir"] == x["case_dir"] and int(float(y["flow_veh_h_lane"])) == q for y in cpairs)]
    assert len(rr) == 5
    aa = cohort_stats(rr, "cooperative")
    pp = cohort_stats(rr, "cooperative", True)
    c_recovery.append(dict(flow=q, all_adjusting=aa, upstream_formed=pp))
    c_recovery_rows.append([q, f'{aa["recovered"]}/{aa["subjects"]}', aa["censored"], f'{pp["recovered"]}/{pp["subjects"]}', pp["censored"], f(pp["conditional_mean_delay_s"], 4)])

doc = f'''# P 独立验收报告

P 在本次四流量独立验收中没有实现全程交通提效：500、750、1000、1500 辆/(h·车道)下，全程平均行程时间均高于同输入 NOA。1500 流量下，640–1100 米主要段的直路差分改善 0.161616 秒，800–1000 米低速积聚也明显减少；这些局部作用没有抵消全程成本。同种子严格消融进一步显示，形成跟驰和补位对主要段及低速积聚有实际贡献，但 P 在 1500 下仍比该消融慢 0.102345 秒，四个流量的燃油均更高。当前结果支持“存在局部组织作用”，不支持“已经由有效编队带来整体交通效率提升”。

## 1. 验收条件与数据范围

本报告使用预先登记的 [P 协议](experiments/2026-10-29-four-flow-attribution/P_protocol.md)和已经冻结的 [portable_P](experiments/2026-10-29-four-flow-attribution/portable_P/PACKAGE.txt)、[portable_C1_P](experiments/2026-10-29-four-flow-attribution/portable_C1_P/PACKAGE.txt)。四个每车道需求流量固定为 500、750、1000、1500 辆/h，独立种子固定为 **6、7、8、9、10**；请求持续 600 秒，绝对仿真上限 900 秒。上游道路长 1000 米、三车道，随后 200 米为两车道；对照直路全长 1200 米、三车道。准备边界为 640 米，物理车道终止点为 1000 米。

P100 包含四流量×五种子×五工况：直路 NOA/P，缩减道路 NOA/F/P。F 表示基本形成加普通合流，P 表示形成加提前编队变换。另有四流量×五种子的 C1_P 缩减道路严格消融 20 例，实际模式元数据为 `cooperative`。P100 累计执行 **48,060 次车辆运行**，C1_P20 累计 **9,612 次**；同一流量、种子的基础请求在方案间复用，每个缩减道路方案的五种子请求数依次为 1296、1916、2546、3854，合计 9612。这里累计运行次数并非互不重复的独立随机车辆样本。120 例全部安全排空、审计合格；统计保留全部尝试，没有成功案例筛选。

各方案使用同一车型、路网、随机发车输入与执行规则：巡航 28.8 m/s、物理最高速度 33.3 m/s、加速能力 5 m/s²、制动能力 10 m/s²、响应参数 0.2 s，车长 4 米，统一 `HBEFA3/PC_G_EU4` 燃油模型。车辆由 SUMO 插入并执行运动，Python 每 0.1 秒提出本车速度和相邻换道请求。每道每步按 `flow×0.1/3600` 的伯努利概率提出请求，不设置等待成组后发车的入口门槛。控制和执行细节见 [原生 SUMO 系统说明](原生SUMO编队变换系统说明.md)。

行程时间 TT 是实际进入到驶出的时间，不含入口等待。交通、燃油、参与率均沿用五个逐种子结果的算术平均；计数单独标注五种子合计。主要段时间依据实测首次越过 640/1100 米门的位置计算，只在正常相邻 0.1 秒帧之间线性插值，漏帧、未通过和删失规则保持冻结口径。定义同模式附加时间为“缩减道路−直路”，DID 为“NOA 附加时间−P 附加时间”：**DID 为正才表示 P 减少了瓶颈附加时间**。F 没有直路病例，不能给 F 填造同模式 DID。

## 2. 全程结果与主要段归因

下表均为秒；P−NOA 为缩减道路全程 TT 的直接差，正值表示 P 更慢。主段与全程 DID 使用同种子、同模式直路控制。

{table('travel_and_DID', ['流量', 'NOA TT', 'F TT', 'P TT', 'P−NOA TT', '640–1100 米 DID', '全程 DID'], first_rows, [dict(flow=q, **did[q]) for q in FLOWS])}

原始来源：[冻结交通表](experiments/2026-10-29-four-flow-attribution/portable_P/tables/traffic_and_attribution.csv)、[完整四流量 CSV](experiments/2026-10-29-four-flow-attribution/P_analysis/four_flow_results.csv)、[归因逐次结果](experiments/2026-10-29-four-flow-attribution/P_analysis/attribution/attributions.csv)。

主要段的绝对时间和直路附加时间如下。前三个流量的 DID 小且为负；1500 下 P 的主要段平均时间比 NOA 短，但全程平均时间仍更长。

{table('main_segment', ['流量', 'NOA 主段', 'F 主段', 'P 主段', 'NOA 主段附加', 'P 主段附加'], main_rows, traffic)}

直路控制也保留了 P 的运行成本。1500 下，P 直路比 NOA 慢 0.120173 秒；100–600 米上游段的附加时间差分为 −0.693194 秒。这一实测上游成本与主要段局部收益同时存在，不能只截取瓶颈附近的改善解释全程结果。

{table('straight_and_upstream', ['流量', 'NOA 直路 TT', 'P 直路 TT', '直路 P−NOA', '100–600 米 DID'], control_rows, [dict(flow=q, upstream_DID=did[q]['reduction_mean_segment_100_600_s_mean']) for q in FLOWS])}

来源：[直路原表](experiments/2026-10-29-four-flow-attribution/portable_P/tables/straight_controls.csv)。1500 流量的五个配对值如下，种子按预登记顺序完整列出；均值不能代替这些方向和幅度不同的结果。

{table('1500_seed_pairs', ['种子', 'NOA TT', 'P TT', 'P−NOA TT'], [[r['seed'], f(r['NOA_TT_s']), f(r['P_TT_s']), f(r['P_minus_NOA_TT_s'], signed=True)] for r in paired1500], paired1500)}

这五个差的均值为 +0.936135 秒。来源：[1500 逐次 CSV](experiments/2026-10-29-four-flow-attribution/P_analysis/flow_1500/native_comparison/runs.csv)、[原始配对 CSV](experiments/2026-10-29-four-flow-attribution/P_analysis/flow_1500/native_comparison/pairs.csv)。未剔除种子 6、7 的较大劣化，也未用种子 8、9 的改善替代整体结果。

## 3. 燃油、低速积聚与断面通过量

低速车辆秒是 [100,600) 秒内、800≤x<1000 米区域中 `v<5 m/s` 的车辆数积分；低速占比的分母为同区域全部车辆秒。区域速度是同窗内车辆时间加权平均，不是全路段平均速度。1000 米断面流量为 [100,600] 秒首次实测通过数除以 500 秒再换算为辆/h，是有限时窗通过量，不称为饱和通行能力。燃油为 SUMO 实测总燃油 mg/实际行驶距离 m，数值单位 g/km，没有额外假定编队空气阻力收益。

{table('fuel_low_speed_flow', ['流量', '方案', '燃油 g/km', '低速车辆秒', '低速占比 %', '区域速度 m/s', '1000 米通过量 辆/h'], traffic_rows, traffic)}

1500 下 P 将低速车辆秒从 NOA 的 213.10 降至 13.68，但断面通过量从 4658.40 变为 4641.12 辆/h，全程 TT 从 42.660825 升至 43.596960 秒，燃油从 63.336 升至 83.462 g/km。局部少停车的作用清楚可见，整体效率和燃油结果却没有同步改善。750 下 P 的低速量略低于 NOA，1000 下则略高，低流量本身没有强拥挤可消除。原值见 [交通与归因表](experiments/2026-10-29-four-flow-attribution/portable_P/tables/traffic_and_attribution.csv)。

## 4. 实际多层参与、规模与持续性

冻结几何评价要求至少两层完整结构：三道上游至少六车、两道下游至少四车，并持续确认 1 秒。参与率 PP 是确认成组车辆秒/区域全部车辆秒；stable PP 在同一口径上要求关系保持达到 5 秒。上游区域为 [0,640) 米，下游为 [1000,1200) 米。下列 PP 与 stable PP 单位为百分比；条件平均规模只在存在已确认组的组时间上计算，再平均各个有定义种子的结果，`n` 是有定义种子数，不能将它当作全体车辆的平均队长。逐种子峰值按 6/7/8/9/10 排列，`—` 表示该种子没有满足条件的结构。

上游结果：

{table('upstream_quality', ['流量', '方案', 'PP %', 'stable PP %', '条件平均规模（种子 n）', '逐种子窗口峰值'], quality_rows['upstream'], quality)}

下游结果：

{table('downstream_quality', ['流量', '方案', 'PP %', 'stable PP %', '条件平均规模（种子 n）', '逐种子窗口峰值'], quality_rows['downstream'], quality)}

P 的下游 PP 为 10.0973%、15.3432%、18.6693%、12.6170%，高于 F；但下游 stable PP 仅为 0.6775%、0.9468%、1.1353%、0.6738%。P 的上游 PP 则为 0、0.2519%、0.3918%、0.6616%，连续流在 640 米长上游区域中的完整成组仍不足。不能把下游结构的存在，写成上游已形成的同一整队成功保持并通过瓶颈。NOA 的检测值仅表示偶然的物理几何结构；例如 1500 下游一个种子出现四车结构，不称为 NOA 主动编队。

这里需要同时保留 200 米下游观察窗的限制。以七层十四车的目标为例，同道层距 30 米、交错相位 15 米对应纵向跨度 `6×30+15=195` 米。在 28.8 m/s 下，该结构完整落入 200 米窗的时间只有 `(200−195)/28.8≈0.17` 秒，小于 1 秒确认时间。因此峰值是**窗口内确认规模**，五秒指标也受空间边界删失影响，不能直接据此判定整条长队的全程规模和寿命。这个限制不改变上游 640 米区域 PP 仍低的实测结论。

内部关系断裂和边界删失保留为不同计数。前者表示曾参与已确认结构的物理同层/邻层关系在区域内部消失；后者表示关系因成员跨出观察边界而不再可见。两者计数单位都是“关系”，不是车辆或整队次数。下表为五种子合计，不能把边界删失加作内部断裂，也不能仅凭低 stable PP 推断控制在整个道路上失稳。

{table('relations', ['流量', '方案', '上游内部断裂', '上游边界删失', '下游内部断裂', '下游边界删失'], relation_rows, relations)}

来源：[编队质量 CSV](experiments/2026-10-29-four-flow-attribution/portable_P/tables/formation_quality.csv)和每流量冻结原始 JSON（[500](experiments/2026-10-29-four-flow-attribution/portable_P/data/native_flow_500.json.gz)、[750](experiments/2026-10-29-four-flow-attribution/portable_P/data/native_flow_750.json.gz)、[1000](experiments/2026-10-29-four-flow-attribution/portable_P/data/native_flow_1000.json.gz)、[1500](experiments/2026-10-29-four-flow-attribution/portable_P/data/native_flow_1500.json.gz)）。

## 5. 原上游成员的恢复与删失

恢复沿用冻结评价器的实际定义：车辆首次被观测到 x≥640 米时开始计时，随后在 [640,1200) 米内确认其属于两道完整结构即记为恢复事件。因此它可能发生在物理瓶颈之前，也不要求原有组员保持同一组身份。“原上游成员”只包括开始调整前已经在三道区域确认过完整结构的车辆；“全部调整车辆”还包含此前未成组、在后段才新形成结构的车辆。这两个分母必须区分。

下表计数合并五种子。条件均值仅对观察到事件的**原上游成员**计算，从首次实测进入准备区到首次两道确认的延迟；其样本数就是该列恢复分子。未恢复者一直保留在分母并列为删失，不设延迟为零，也不进入条件均值。`—` 表示没有事件，不能解释成零秒恢复。此次安全排空并不等于结构恢复：车辆驶出道路之前没有确认事件，仍为恢复指标删失。

{table('recovery', ['流量', '方案', '全部调整：恢复/分母', '全部删失', '原上游：恢复/分母', '原上游删失', '原上游条件均值 s'], rec_rows, rec_stats)}

P 的原上游恢复结果依次为 0/0、24/24、57/60、76/150，删失为 0、0、3、74。500 没有原上游成组成员，不能用全部调整车辆中的 234 个两道事件宣称上游整队恢复。1500 中 962 个全部调整事件也不等于 962 个原队成员恢复；原上游实际确认恢复的只有 76 个。条件均值不衡量那些未恢复成员的真实恢复时间。

来源：[恢复计数表](experiments/2026-10-29-four-flow-attribution/portable_P/tables/recovery_counts.csv)及原始恢复记录（[500](experiments/2026-10-29-four-flow-attribution/portable_P/data/recovery_flow_500.json.gz)、[750](experiments/2026-10-29-four-flow-attribution/portable_P/data/recovery_flow_750.json.gz)、[1000](experiments/2026-10-29-four-flow-attribution/portable_P/data/recovery_flow_1000.json.gz)、[1500](experiments/2026-10-29-four-flow-attribution/portable_P/data/recovery_flow_1500.json.gz)）。条件均值合并这五个种子中实际观察到的事件，按事件数加权，并与原逐次条件均值、恢复数交叉核对。

## 6. C1_P 严格消融

C1_P 从最终 P 冻结源独立复制，仅在 cooperative 决策中关闭形成跟驰 `_following` 和自由补位 `_fill`；普通超车仍只允许 NOA，P 与 C1_P 的协作模式均不启用普通超车。helper、接收开隙、合流、joining、pending、本车执行反馈、安全及共同构型定义保持 P 的实现。引擎只增加 cooperative 模式枚举，规则变化限于 `_decide` 选择。八项静态测试检查固定局部状态下 C1_P 与旧 C1_H 的动作/记忆一致，并确认新 pair/follow/fill 分支在 cooperative 下不执行；旧病例没有复用到本批统计。

20 个新病例均来自种子 6–10，与对应 P 缩减道路病例逐一具有**完全相同的原始共同参数 SHA256**，包括浮点流量的 JSON 表示；随机需求 SHA、车辆请求也逐一相同。普通超车动作总数为零，未采用整数/浮点规范化例外。cooperative 直路仍完整委派 NOA，继承的旧直路证明单独注明来源，不冒充本批新的直路病例。来源：[逐对配对及原 SHA](experiments/2026-10-29-four-flow-attribution/portable_C1_P/tables/pairs.csv)、[冻结 source](experiments/2026-10-29-four-flow-attribution/portable_C1_P/provenance/freeze.json)、[独立核验](experiments/2026-10-29-four-flow-attribution/portable_C1_P/independent_verification.json)。

下表“P 主段增量收益”是 P 相对 C1_P 的同模式直路附加时间减少，正值表示 P 更好；C1_P−P TT 的正值表示 C1_P 更慢。TT 与主段增量收益单位为秒，燃油为 g/km。

{table('C1_P_comparison', ['流量', 'C1_P TT', 'P TT', 'C1_P−P TT', 'P 主段增量收益', 'C1_P 低速车辆秒', 'P 低速车辆秒', 'C1_P 燃油', 'P 燃油'], c_rows, cr)}

形成跟驰和补位的联合启用在四个流量均改善主段附加时间，并减少低速积聚，1500 的主段增量收益为 0.987646 秒；但其全程 TT 并非四个流量都更好，1500 的 P 仍比 C1_P 慢 0.102345 秒，燃油从 67.590 增至 83.462 g/km。这个对照隔离的是形成跟驰与补位两类规则的联合开关，不能进一步把全部收益分配给其中某一条，也不能用它代替“完整成组结构导致全程提效”的结论。

C1_P 的同口径区域速度、低速占比和断面通过量如下：

{table('C1_P_region', ['流量', '区域速度 m/s', '低速占比 %', '1000 米通过量 辆/h'], c_window_rows, cr)}

C1_P 的上游没有确认多层结构；下游也只有很低的几何参与。其条件规模和逐种子峰值如下，定义与 P 完全相同：

{table('C1_P_participation', ['流量', '区域', 'PP %', 'stable PP %', '条件平均规模（种子 n）', '逐种子窗口峰值'], c_quality_rows, cnative)}

C1_P 的内部关系断裂与边界删失为五种子合计：

{table('C1_P_relations', ['流量', '上游内部断裂', '上游边界删失', '下游内部断裂', '下游边界删失'], c_relation_rows, cnative)}

恢复口径也相同。C1_P 没有开始调整前已在上游确认成组的成员，其全部调整车辆中的少量两道事件属于新结构检测，不能称为原队恢复：

{table('C1_P_recovery', ['流量', '全部调整：恢复/分母', '全部删失', '原上游：恢复/分母', '原上游删失', '原上游条件均值 s'], c_recovery_rows, c_recovery)}

全部对照、逐次记录和删失数据见 [C1_P 流量均值](experiments/2026-10-29-four-flow-attribution/portable_C1_P/tables/flow_means.csv)、[逐次 CSV](experiments/2026-10-29-four-flow-attribution/portable_C1_P/tables/runs.csv)、[恢复原记录](experiments/2026-10-29-four-flow-attribution/portable_C1_P/data/recovery_summary.json.gz)。

## 7. 源、工程证据与可复核范围

P 规则 SHA256 为 `8d112d79dce42b68fc4aba986aa52b5241c3ee4e8b6d8061cd04b80bcdb75864`，执行器为 `6a530098146e85a637b4f29d580d61877c7a54b3a7e15858724651d80e8956b0`，wrapper 为 `cf7a371677a08dd312ae904f410d26070452d464314b12b0a2b5943f0b2d1385`。C1_P 规则为 `bbd5857e6f951183743f51ed280c8a7a58de666c541f2232222fefd34672d0aa`，来源差异和独立标签在包中明示。归因、原生比较、多层和恢复评价器沿用既有冻结版本，不为 P 调整阈值或指标；跨流量分别评价，未将不同流量混入旧分组键。

当前 [主线集成证据](../tmp/P_main_integration_evidence.json)记录主线规则与最终 release 逐字节一致、187 项核心测试及其中 29 个子测试通过、9 项根 GUI 测试通过，11 项新增几何边界测试迁移保持方法一致，两个真实六车门均 6/6 安全排空并确认峰值六车。这些是工程功能与集成回归证据，主线程正式审核后补入其正式证据链；它们不把本批全程阴性结果改写为研究提效成功。

两个便携包的 JSON/CSV 保持原字节，逐车 CSV/JSON 无损压缩，源码去重，原 0.1 秒大轨迹以路径和 SHA 绑定。便携核验脚本复核保存字节、原始车辆运行、已有指标和配对；从位置轨迹重新计算几何仍需读取所绑定的原轨迹。P 包 manifest SHA256 为 `5622ced9d322ca8df061adf2a6a49d7b0625f4ca5686ce832d4d1b3b4949b15b`，C1_P 为 `2eb98e062b7806fc2794777747d1f90e2fcec014c6241d3314373e07404394ed`。本报告各源表 SHA、逐种子差、条件均值和表格取值记录在 [数值核对证据](../tmp/P_report_audit.json)。

旧 D/H/C0/C1 的种子 1–5 属于另一批校准和方法诊断，见 [旧四流量归因报告](2026-10-29-四流量瓶颈归因报告.md)，不与本批新种子合并平均。系统整体接口见 [原生 SUMO 说明](原生SUMO编队变换系统说明.md)；旧运动后端的边界见 [纯规则系统说明](纯规则编队系统说明.md)。[MATLAB 车辆控制调用链核查](2026-10-29-MATLAB车辆控制调用链核查.md)是静态源码证据，不是 Cai 方法在本工况下的重跑性能。没有原始、同工况实测数据，因此本报告不给 Cai 排列数值，也不以自建集中式代码替代原方法比较。
'''

if OUT.exists():
    old_audit = json.loads(AUDIT.read_text(encoding="utf-8"))
    assert old_audit["report_sha256"] == sha(OUT.read_bytes()), "Report was changed outside this writing unit"
OUT.write_text(doc, encoding="utf-8", newline="\n")
after = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for base in (P, C) for p in base.rglob("*") if p.is_file()}
assert before == after, "Frozen package changed while report was written"
audit = dict(
    generated_utc=datetime.now(timezone.utc).isoformat(),
    report=str(OUT), report_sha256=sha(OUT.read_bytes()),
    generator_sha256=sha(Path(__file__).read_bytes()),
    sources=SOURCES,
    frozen_package_files_checked=len(before), frozen_package_bytes_unchanged=before == after,
    study=dict(seeds=[6, 7, 8, 9, 10], flows=list(FLOWS), P_cases=100, P_requests=48060, C1_P_cases=20, C1_P_requests=9612, no_success_only_means=True, all_cases_eligible=True),
    table_values=CELLS, P_1500_paired_TT=paired1500,
    recovery_formula="Existing conditional_mean_delay_s: sum observed per-vehicle delay_s / observed event count; pooled across the five fixed seeds; checked against original per-run recovery-weighted means. Censored delay_s stays undefined.",
    recovery=rec_stats, C1_P_recovery=c_recovery,
    relation_count_policy="Sum original five per-run existing relation counts; no new metric or threshold.",
    relations=relations,
    assertions=dict(source_seed_protocol_bound=True, all_P_cases_eligible=True, P_requests_match_48060=True, C1_P_requests_match_9612=True, C1_P_raw_parameter_sha_equal_all20=True, C1_P_ordinary_overtake_zero=True, P_1500_original_CSV_pairs_match=True, recovery_per_vehicle_counts_and_conditional_means_match=True),
)
AUDIT.write_text(json.dumps(audit, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
print(json.dumps(dict(report=str(OUT), report_bytes=OUT.stat().st_size, report_sha256=audit["report_sha256"], audit=str(AUDIT), source_files=len(SOURCES), tables=len(CELLS), frozen_package_files_unchanged=len(before)), ensure_ascii=False))
