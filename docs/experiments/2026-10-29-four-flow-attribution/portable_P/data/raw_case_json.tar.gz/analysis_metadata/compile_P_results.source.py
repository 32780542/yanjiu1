"""Flatten existing P100 measures into a compact report table; no new metrics."""
import csv
import hashlib
import json
from pathlib import Path


BASE = Path("D:/yanjiu1/keyan1/docs/experiments/2026-10-29-four-flow-attribution/P_analysis")


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    attr = read(BASE / "attribution/summary.json")
    verified = read(BASE / "postverification.json")
    if not verified["passed"]:
        raise ValueError("H postverification is not passing")
    rows = []
    for flow in (500, 750, 1000, 1500):
        native = read(BASE / f"flow_{flow}/native_comparison/summary.json")
        reduction = next(r for r in attr["attribution_means"] if r["flow_veh_h_lane"] == flow)
        for mode in ("noa", "formation", "transform"):
            traffic = next(r for r in attr["run_means"] if r["flow_veh_h_lane"] == flow and r["scenario"] == "lane_drop" and r["mode"] == mode)
            effect = next((r for r in attr["scenario_effect_means"] if r["flow_veh_h_lane"] == flow and r["mode"] == mode), None)
            physics = next(r for r in verified["physics"] if r["flow"] == flow and r["mode"] == mode)
            recover = next(r for r in verified["recovery_counts"] if r["flow"] == flow and r["mode"] == mode)
            layer_mean = next(r for r in native["run_means"] if r["scenario"] == "lane_drop" and r["mode"] == mode)
            members = sorted((r for r in native["runs"] if r["scenario"] == "lane_drop" and r["mode"] == mode), key=lambda r: r["seed"])
            row = dict(flow_veh_h_lane=flow, mode=mode, attempted_seeds=traffic["attempted_n"], eligible_seeds=traffic["eligible_n"],
                TT_s=traffic["mean_travel_time_s_mean"], fuel_g_km=physics["fuel_g_per_km_mean"],
                region_window_speed_mps=traffic["region_mean_speed_mps_mean"],
                low_speed_vehicle_s=traffic["region_low_speed_vehicle_s_mean"],
                low_speed_fraction=traffic["region_low_speed_fraction_mean"],
                flow_1000m_veh_h=traffic["flow_1000m_veh_h_mean"],
                main_640_1100_s=traffic["mean_segment_640_1100_s_mean"],
                main_drop_minus_straight_s=effect["additional_mean_segment_640_1100_s_mean"] if effect else None,
                main_NOA_minus_TF_additional_reduction_s=reduction["reduction_mean_segment_640_1100_s_mean"] if mode == "transform" else None,
                TT_NOA_minus_TF_additional_reduction_s=reduction["reduction_mean_travel_time_s_mean"] if mode == "transform" else None)
            for region in ("upstream", "downstream"):
                for metric in ("formation_participation_rate", "stable_participation_rate", "mean_multilayer_size", "peak_multilayer_size"):
                    row[region + "_" + metric + "_mean"] = layer_mean[region + "_" + metric + "_mean"]
                    row[region + "_" + metric + "_n"] = layer_mean[region + "_" + metric + "_n"]
                row[region + "_peak_by_seed"] = [r.get(region + "_peak_multilayer_size") for r in members]
            for group in ("all_adjusting", "upstream_formed"):
                for key, value in recover[group].items():
                    row[group + "_" + key] = value
            rows.append(row)
    definitions = dict(
        averaging="Existing arithmetic mean over the original five eligible per-seed measures; no successful-only averages. Recovery counts sum original per-seed counts.",
        speed="800<=x<1000m, [100,600)s measured vehicle-time-weighted mean speed; not whole-route mean speed.",
        low_speed="v<5m/s in the same region/window; vehicle-seconds and fraction of regional vehicle exposure.",
        flow="1000m first crossings in inclusive [100,600]s / 500s * 3600; no saturation capacity inference.",
        main="640–1100m measured first crossing duration. Same-mode drop minus straight; positive added delay. NOA-minus-TF additional reduction positive means improvement. formation lacks a same-mode straight case and its difference remains null.",
        geometry="Upstream 3 lanes [0,640)m; downstream 2 lanes [1000,1200)m. PP fractions 0–1, confirmed >=2 full layers; stable PP uses frozen 5s hold. Conditional size means and peak means retain their original defined-seed n; actual peaks by seed 6–10 are also retained, null means no qualifying structure.",
        recovery="all_adjusting subjects/recovered/censored are all observed adjustment subjects; upstream_formed restricts to vehicles confirmed before adjustment. Unobserved recovery stays censored. NOA geometry is not controlled formation.",
        source="Frozen independent evaluators and H77c011 rules; all original per-case records remain in neighboring files.")
    (BASE / "four_flow_results.json").write_text(json.dumps(dict(definitions=definitions, rows=rows), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (BASE / "four_flow_results.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, list(rows[0]))
        writer.writeheader()
        writer.writerows({k: json.dumps(v) if isinstance(v, list) else v for k, v in row.items()} for row in rows)
    (BASE / "compile_P_results.source.py").write_bytes(Path(__file__).read_bytes())
    hashes = {str(p.relative_to(BASE)): sha(p) for p in sorted(BASE.rglob("*")) if p.is_file() and p.name != "artifact_hashes.json"}
    (BASE / "artifact_hashes.json").write_text(json.dumps(hashes, indent=2) + "\n", encoding="utf-8")
    if any(sha(BASE / name) != value for name, value in hashes.items()):
        raise ValueError("H final artifact hash mismatch")
    print(json.dumps(dict(output=str(BASE), rows=len(rows), artifacts=len(hashes), passed=True)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
