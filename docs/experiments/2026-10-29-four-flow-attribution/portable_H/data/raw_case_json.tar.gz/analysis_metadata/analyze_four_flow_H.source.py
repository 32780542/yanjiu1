"""Formal H100 analysis: refuse partial studies, audit snapshots, reuse evaluators."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys


ROOT = Path(__file__).resolve().parents[1]
VARIANT = ROOT / "variants/phase5g_pure_formation"
FROZEN = ROOT / "tmp/four_flow_D_analysis_frozen"
EVALUATOR_SHA256 = "deea86e38bf6de44eb130216fe4c9f370803171295002f99b790ec793b066ec9"
SCENARIO_MODES = (("straight3", ("noa", "transform")),
                  ("lane_drop", ("noa", "formation", "transform")))
H_RELEASE = ROOT / "tmp/head_group_H_release"
H_RULES_SHA256 = "77c0111530560db30e97dc466bcdaf276a78cb7dd7192767e9a2d51b97eab2d2"
H_ENGINE_SHA256 = "6a530098146e85a637b4f29d580d61877c7a54b3a7e15858724651d80e8956b0"
H_WRAPPER_SHA256 = "cf7a371677a08dd312ae904f410d26070452d464314b12b0a2b5943f0b2d1385"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def audit_release(study, release=H_RELEASE):
    """Bind H protocol to independently named release hashes and saved bytes."""
    study, release = Path(study), Path(release)
    frozen, protocol = read(release / "freeze.json"), read(study / "protocol.json")
    hashes = frozen["source_sha256"]
    if (hashes.get("noa/native_rules.py") != H_RULES_SHA256
            or hashes.get("experiments/native_sumo.py") != H_ENGINE_SHA256
            or frozen.get("wrapper_sha256") != H_WRAPPER_SHA256 or len(hashes) != 6):
        raise ValueError("H_release_anchor_mismatch")
    if (protocol.get("source_sha256") != hashes or protocol.get("wrapper_sha256") != H_WRAPPER_SHA256
            or protocol.get("jobs") != 4):
        raise ValueError("H_protocol_release_mismatch")
    for name, expected in hashes.items():
        if sha(release / name) != expected:
            raise ValueError("H_release_source_snapshot_mismatch:" + name)
    if sha(release / "run_flow_study.py") != H_WRAPPER_SHA256:
        raise ValueError("H_release_wrapper_snapshot_mismatch")
    if not all(row["ast_identical"] for row in frozen.get("formatting", {}).values()):
        raise ValueError("H_release_formatting_AST_mismatch")
    return dict(passed=True, release_dir=str(release.resolve()), controlled_modules=len(hashes),
                release_freeze_sha256=sha(release / "freeze.json"), source_sha256=hashes,
                rules_sha256=H_RULES_SHA256, engine_sha256=H_ENGINE_SHA256,
                wrapper_sha256=H_WRAPPER_SHA256, jobs=4)


def audit_study(study, operation):
    """Require successful outer completion and a complete, source-bound H100 matrix."""
    study, operation = Path(study).resolve(), Path(operation).resolve()
    result_path = operation / "result.json"
    if not result_path.is_file():
        raise ValueError("outer_operation_not_completed")
    outer = read(result_path)
    if outer.get("status") != "completed" or outer.get("returncode") != 0:
        raise ValueError("outer_operation_not_completed_zero")
    protocol = read(study / "protocol.json")
    if (protocol.get("case_count") != 100 or set(protocol["flows"]) != {500, 750, 1000, 1500}
            or set(protocol["seeds"]) != {1, 2, 3, 4, 5}
            or protocol["duration_s"] != 600 or protocol["max_time_s"] != 900):
        raise ValueError("protocol_matrix_mismatch")
    expected = {(flow, seed, scenario, mode) for flow in protocol["flows"]
                for seed in protocol["seeds"] for scenario, modes in SCENARIO_MODES for mode in modes}
    paths = [(study / p).resolve() for p in read(study / "manifest.json")["cases"]]
    records = read(study / "run_status.json")
    if len(paths) != 100 or len(set(paths)) != 100 or len(records) != 100:
        raise ValueError("incomplete_or_duplicate_matrix")
    by_path = {Path(r["run_dir"]).resolve(): r for r in records}
    if len(by_path) != 100 or set(by_path) != set(paths):
        raise ValueError("status_manifest_matrix_mismatch")
    controlled = protocol["source_sha256"]
    if not controlled:
        raise ValueError("missing_protocol_source")
    for name, digest in controlled.items():
        if sha(study / "source" / name) != digest:
            raise ValueError("study_source_digest_mismatch:" + name)
    if sha(study / "run_flow_study.py") != protocol["wrapper_sha256"]:
        raise ValueError("study_wrapper_source_digest_mismatch")
    actual, audited, flow_counts = set(), [], {}
    for path in paths:
        if not path.is_relative_to(study):
            raise ValueError("case_outside_study_matrix")
        source, result, record = read(path / "input.json"), read(path / "result.json"), by_path[path]
        config = source["case"]
        key = config["flow_veh_h_lane"], config["seed"], config["scenario"], config["mode"]
        if key in actual:
            raise ValueError("duplicate_case_matrix_identity")
        actual.add(key)
        if any(result.get(k) != config[k] for k in ("flow_veh_h_lane", "seed", "scenario", "mode")):
            raise ValueError("input_result_matrix_identity_mismatch")
        if (record["flow"], record["seed"], record["scenario"], record["mode"]) != key:
            raise ValueError("status_matrix_identity_mismatch")
        if (result.get("status") in (None, "starting", "running")
                or result["status"] != record["status"]):
            raise ValueError("nonterminal_case_matrix")
        if config["demand_duration_s"] != 600 or config["max_time_s"] != 900:
            raise ValueError("case_protocol_matrix_parameters_mismatch")
        if source.get("source_sha256") != controlled or result.get("source_sha256") != controlled:
            raise ValueError("case_protocol_source_digest_mismatch")
        for name, digest in controlled.items():
            if sha(path / "source" / name) != digest:
                raise ValueError("case_snapshot_source_digest_mismatch:" + str(path) + ":" + name)
        flow = f"{key[0]:g}"
        flow_counts[flow] = flow_counts.get(flow, 0) + 1
        audited.append(dict(case_dir=str(path), flow=key[0], seed=key[1], scenario=key[2], mode=key[3],
                            status=result["status"], input_sha256=sha(path / "input.json"),
                            result_sha256=sha(path / "result.json"), source_sha256=controlled))
    if actual != expected:
        raise ValueError("expected_case_matrix_mismatch")
    for flow in protocol["flows"]:
        flow_manifest = study / f"flow_{flow:g}_manifest.json"
        members = [(flow_manifest.parent / p).resolve() for p in read(flow_manifest)["cases"]]
        expected_members = {Path(r["case_dir"]) for r in audited if r["flow"] == flow}
        if len(members) != 25 or len(set(members)) != 25 or set(members) != expected_members:
            raise ValueError("flow_manifest_matrix_mismatch")
    return dict(passed=True, case_count=len(paths), flow_counts=flow_counts,
                study_dir=str(study), operation_dir=str(operation),
                protocol_sha256=sha(study / "protocol.json"), protocol=protocol,
                manifest_sha256=sha(study / "manifest.json"),
                run_status_sha256=sha(study / "run_status.json"),
                outer_operation_result_sha256=sha(result_path), outer_operation=outer,
                source_snapshot_case_count=len(audited), cases=audited)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("study", type=Path)
    parser.add_argument("operation", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args(argv)
    study, output = args.study.resolve(), args.output.resolve()
    if output.exists():
        raise FileExistsError(output)
    audit = audit_study(study, args.operation)
    audit["H_release_audit"] = audit_release(study)
    frozen_hashes = read(FROZEN / "freeze.json")
    for name, digest in frozen_hashes["source_sha256"].items():
        if sha(FROZEN / name) != digest:
            raise ValueError("frozen_analysis_source_mismatch:" + name)
    if frozen_hashes["source_sha256"]["experiments/bottleneck_attribution.py"] != EVALUATOR_SHA256:
        raise ValueError("frozen_attribution_evaluator_mismatch")
    layer_digest = audit["protocol"]["source_sha256"]["experiments/complete_layers.py"]
    if frozen_hashes["source_sha256"]["experiments/complete_layers.py"] != layer_digest:
        raise ValueError("frozen_layer_source_not_study_protocol")
    sys.path.insert(0, str(FROZEN))
    from experiments.bottleneck_attribution import summarize_cases as attribute
    from experiments.native_comparison import summarize_cases as native
    from experiments.native_recovery import summarize_manifest as recovery

    output.mkdir(parents=True, exist_ok=False)
    shutil.copytree(FROZEN, output / "source_evaluators")
    shutil.copy2(__file__, output / "analyze_four_flow_H.source.py")
    for name in ("protocol.json", "manifest.json", "run_status.json", "run_flow_study.py"):
        shutil.copy2(study / name, output / name)
    shutil.copy2(args.operation / "result.json", output / "outer_operation_result.json")
    shutil.copy2(H_RELEASE / "freeze.json", output / "H_release_freeze.json")
    shutil.copy2(ROOT / "tmp/parallel_study_equivalence.json", output / "parallel_study_equivalence.json")
    shutil.copy2(ROOT / "tmp/H_analysis_freeze.json", output / "H_analysis_freeze.json")
    write(output / "data_audit.json", audit)
    progress = dict(status="analyzing", started_utc=datetime.now(timezone.utc).isoformat(),
                    evaluator_sha256=EVALUATOR_SHA256, units=[])
    write(output / "analysis_status.json", progress)
    attr = attribute(study / "manifest.json", output / "attribution")
    progress["units"].append(dict(unit="bottleneck_attribution", runs=len(attr["runs"]),
                                 eligible=sum(r["attribution_eligible"] for r in attr["runs"])))
    write(output / "analysis_status.json", progress)
    print(json.dumps(progress["units"][-1]), flush=True)
    native_reports, recovery_reports = {}, {}
    for flow in audit["protocol"]["flows"]:
        dest = output / f"flow_{flow:g}"
        dest.mkdir()
        manifest = study / f"flow_{flow:g}_manifest.json"
        shutil.copy2(manifest, dest / "manifest.json")
        n = native(manifest, dest / "native_comparison")
        native_reports[flow] = n
        progress["units"].append(dict(unit=f"flow_{flow:g}_native_comparison", runs=len(n["runs"]),
                                     eligible=sum(r["performance_eligible"] for r in n["runs"])))
        write(output / "analysis_status.json", progress)
        print(json.dumps(progress["units"][-1]), flush=True)
        r = recovery(manifest, dest / "recovery")
        recovery_reports[flow] = r
        progress["units"].append(dict(unit=f"flow_{flow:g}_recovery", runs=len(r["runs"]),
                                     subjects=sum(v["subjects"] for v in r["runs"]),
                                     recovered=sum(v["recovered"] for v in r["runs"])))
        write(output / "analysis_status.json", progress)
        print(json.dumps(progress["units"][-1]), flush=True)
    overview = dict(
        audited_cases=100, requested=sum(r["requested"] for r in attr["runs"]),
        attribution_eligible_runs=sum(r["attribution_eligible"] for r in attr["runs"]),
        data_audit_passed=True, evaluator_sha256=EVALUATOR_SHA256,
        attribution_means=attr["attribution_means"],
        run_means=attr["run_means"], scenario_effect_means=attr["scenario_effect_means"],
        scenario_pair_means=attr["scenario_pair_means"], ablation_means=attr["ablation_means"],
        native_run_means={f"{f:g}": r["run_means"] for f, r in native_reports.items()},
        native_pair_means={f"{f:g}": r["pair_means"] for f, r in native_reports.items()},
        recovery_statistics_note="Reuse frozen native_recovery; observed delays are conditional and censored subjects remain explicit",
    )
    write(output / "analysis_overview.json", overview)
    progress.update(status="completed", completed_utc=datetime.now(timezone.utc).isoformat())
    write(output / "analysis_status.json", progress)
    artifact_hashes = {str(p.relative_to(output)): sha(p) for p in sorted(output.rglob("*")) if p.is_file()}
    write(output / "artifact_hashes.json", artifact_hashes)
    print(json.dumps(dict(output=str(output), status="completed", cases=100,
                          eligible=overview["attribution_eligible_runs"])), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
