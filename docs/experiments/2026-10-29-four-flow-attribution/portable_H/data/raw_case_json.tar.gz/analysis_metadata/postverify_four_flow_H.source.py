"""Independent H100 output binding, failure-retention and per-vehicle checks."""
from collections import defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path


ROOT = Path("D:/yanjiu1/keyan1")
BASE = ROOT / "docs/experiments/2026-10-29-four-flow-attribution/H_analysis"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    status = read(BASE / "analysis_status.json")
    if status["status"] != "completed":
        raise ValueError("H analysis is not complete")
    hashes = read(BASE / "artifact_hashes.json")
    mismatches = [name for name, expected in hashes.items() if sha(BASE / name) != expected]
    if mismatches:
        raise ValueError("H artifact hash mismatch: " + str(mismatches))
    audit = read(BASE / "data_audit.json")
    attr = read(BASE / "attribution/summary.json")
    by_case = {r["case_dir"]: r for r in attr["runs"]}
    study = Path(audit["study_dir"])
    discovered = {str(p.parent.resolve()) for p in study.glob("flow_*/*/input.json")}
    if discovered != set(by_case):
        raise ValueError("H study contains case directories outside the retained 100-case manifest")
    release = read(BASE / "H_release_freeze.json")
    if not audit["passed"] or not audit["H_release_audit"]["passed"]:
        raise ValueError("H study/release audit failed")
    if release["source_sha256"] != audit["protocol"]["source_sha256"]:
        raise ValueError("H freeze/protocol source disagreement")
    native_runs, recovery_runs = [], []
    physics, recovery_counts = [], []
    for flow in (500, 750, 1000, 1500):
        n = read(BASE / f"flow_{flow}/native_comparison/summary.json")
        rec = read(BASE / f"flow_{flow}/recovery/summary.json")
        if len(n["runs"]) != 25 or len(rec["runs"]) != 25:
            raise ValueError("H flow does not retain all 25 cases")
        native_runs += n["runs"]
        recovery_runs += rec["runs"]
        for run in n["runs"]:
            original = by_case[run["case_dir"]]
            if any(run[k] != original[k] for k in ("input_sha256", "result_sha256", "positions_sha256", "trips_sha256")):
                raise ValueError("H native/attribution source input binding mismatch")
        for run in rec["runs"]:
            original = by_case[run["case_dir"]]
            if any(run[k] != original[k] for k in ("positions_sha256", "trips_sha256")):
                raise ValueError("H recovery/attribution input binding mismatch")
        for mode in ("noa", "formation", "transform"):
            geometry = next(r for r in n["run_means"] if r["scenario"] == "lane_drop" and r["mode"] == mode)
            physics.append(dict(flow=flow, mode=mode, attempted=geometry["attempted_n"], eligible=geometry["eligible_n"],
                **{key: geometry.get(key) for key in (
                    "upstream_formation_participation_rate_mean", "upstream_stable_participation_rate_mean",
                    "upstream_mean_multilayer_size_mean", "upstream_peak_multilayer_size_mean",
                    "downstream_formation_participation_rate_mean", "downstream_stable_participation_rate_mean",
                    "downstream_mean_multilayer_size_mean", "downstream_peak_multilayer_size_mean", "fuel_g_per_km_mean")}))
            selected = [r for r in rec["runs"] if r["scenario"] == "lane_drop" and r["mode"] == mode]
            recovery_counts.append(dict(flow=flow, mode=mode,
                all_adjusting={k: sum(r[k] for r in selected) for k in ("subjects", "recovered", "censored")},
                upstream_formed={k: sum(r["upstream_formed"][k] for r in selected) for k in ("subjects", "recovered", "censored")}))
    for groups in (attr["run_means"], attr["attribution_means"], attr["scenario_effect_means"], attr["scenario_pair_means"], attr["ablation_means"]):
        for row in groups:
            if not row["group_eligible"] and any(v is not None for k, v in row.items() if k.endswith("_mean")):
                raise ValueError("H failure group contains a success-only mean")
    segments = defaultdict(list)
    vehicle_count = 0
    with (BASE / "attribution/vehicles.csv").open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            vehicle_count += 1
            if row["gate_640_s"] and row["gate_1100_s"]:
                segments[row["case_dir"]].append(float(row["gate_1100_s"]) - float(row["gate_640_s"]))
    for case, run in by_case.items():
        values = segments[case]
        if run["attribution_eligible"]:
            if len(values) != run["requested"] or not math.isclose(sum(values) / len(values), run["mean_segment_640_1100_s"], abs_tol=1e-8):
                raise ValueError("H primary time disagrees with measured vehicle gates")
    if len(by_case) != 100 or len(native_runs) != 100 or len(recovery_runs) != 100:
        raise ValueError("H total matrix size mismatch")
    report = dict(passed=True, artifacts_checked=len(hashes), input_binding_mismatches=[],
        case_count=100, vehicle_records=vehicle_count, requested=sum(r["requested"] for r in native_runs),
        study_case_inventory_matches_manifest=True, study_case_directories=len(discovered),
        native_eligible=sum(r["performance_eligible"] for r in native_runs),
        attribution_eligible=sum(r["attribution_eligible"] for r in by_case.values()),
        all_completed=all(r["all_completed"] for r in native_runs), all_safe=all(r["safe"] for r in native_runs),
        collisions=sum(r["collisions"] or 0 for r in native_runs), teleports=sum(r["teleports"] or 0 for r in native_runs),
        retained_ineligible_cases=[dict(case_dir=r["case_dir"], status=r["status"], issues=r["audit_issues"]) for r in native_runs if not r["performance_eligible"]],
        no_success_only_means=True, primary_segment_checked_from_per_vehicle_gates=True,
        H_source_sha256=release["source_sha256"], H_wrapper_sha256=release["wrapper_sha256"],
        evaluator_sha256=attr["metadata"]["evaluator_source_sha256"],
        physics=physics, recovery_counts=recovery_counts)
    (BASE / "postverification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (BASE / "postverify_four_flow_H.source.py").write_bytes(Path(__file__).read_bytes())
    hashes = {str(p.relative_to(BASE)): sha(p) for p in sorted(BASE.rglob("*")) if p.is_file() and p.name != "artifact_hashes.json"}
    (BASE / "artifact_hashes.json").write_text(json.dumps(hashes, indent=2) + "\n", encoding="utf-8")
    if any(sha(BASE / name) != expected for name, expected in hashes.items()):
        raise ValueError("H final artifact hash mismatch")
    print(json.dumps(dict(output=str(BASE), passed=True, artifacts=len(hashes),
                          native_eligible=report["native_eligible"], attribution_eligible=report["attribution_eligible"],
                          all_safe=report["all_safe"], all_completed=report["all_completed"], requested=report["requested"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
