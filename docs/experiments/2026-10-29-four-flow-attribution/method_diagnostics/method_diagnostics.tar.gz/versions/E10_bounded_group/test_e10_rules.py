"""Minimal local formation-radius and consistent physical-coordinate regressions."""
from dataclasses import replace
import unittest

from noa import native_rules as r


def car(track, x, lane, speed=28.8, y=None):
    return r.Vehicle(track, x, (lane + 0.5) * 3.3 if y is None else y, speed, lane)


class E10RulesTests(unittest.TestCase):
    def test_seventy_meter_front_does_not_pull_a_separate_group(self):
        ego, front = car(0, 100, 0), car(1, 170, 0)
        speed, target, reference = r._following(ego, (front,), 3)
        self.assertAlmostEqual(speed, 28.8)
        self.assertEqual(target, ego.x)
        self.assertIsNone(reference)

    def test_forty_meter_front_still_has_the_real_front_reference(self):
        ego, front = car(0, 100, 0), car(1, 140, 0, 26)
        speed, target, reference = r._following(ego, (front,), 3)
        self.assertEqual(target, 110)
        self.assertEqual(reference, front.track)
        self.assertAlmostEqual(speed, r._request(ego, 110, front.speed))

    def test_fifty_meter_boundary_is_inclusive(self):
        ego, front = car(0, 100, 0), car(1, 150, 0, 26)
        speed, target, reference = r._following(ego, (front,), 3)
        self.assertEqual(target, 120)
        self.assertEqual(reference, front.track)

    def test_safety_still_reads_a_stopped_front_outside_the_group_radius(self):
        ego, front = car(0, 100, 0), car(1, 151, 0, 0)
        cap = r.safe_speed(ego, (front,))
        self.assertLess(cap, r.CRUISE)
        command, _ = r.decide(ego, (front,), r.Memory(), "formation", None)
        self.assertAlmostEqual(command.speed, cap)

    def test_perfect_three_lane_thirty_meter_lattice_does_not_drift(self):
        cars = tuple(car(i, x, lane) for i, (x, lane) in enumerate(((100, 2), (70, 2), (85, 1), (55, 1), (100, 0), (70, 0))))
        for ego in cars:
            speed, target, reference = r._following(ego, tuple(c for c in cars if c.track != ego.track), 3)
            self.assertAlmostEqual(speed, 28.8)
            self.assertAlmostEqual(target, ego.x)

    def test_mutual_phase_errors_are_opposite_during_lateral_motion(self):
        ego, peer = car(0, 100, 0, y=3.0), car(1, 85, 1)
        target_ego = r._following(ego, (peer,), 3)[1]
        target_peer = r._following(peer, (ego,), 3)[1]
        self.assertAlmostEqual((target_ego - 100) + (target_peer - 70), 0)
        physical_error = peer.x + r._physical_phase(peer, 3) - ego.x - r._physical_phase(ego, 3)
        self.assertAlmostEqual(target_ego - ego.x, physical_error / 2)

    def test_phase_is_continuous_when_lateral_midpoint_changes_lane_labels(self):
        epsilon = 0.00001
        before = car(0, 100, 0, 2, y=3.3-epsilon)
        before_peer = car(1, 92, 1, 2, y=3.3+epsilon)
        after = replace(before, lane=1, y=3.3+epsilon)
        after_peer = replace(before_peer, lane=0, y=3.3-epsilon)
        targets = []
        for ego, peer in ((before, before_peer), (after, after_peer)):
            target = r._following(ego, (peer,), 3)[1]
            physical_error = peer.x + r._physical_phase(peer, 3) - ego.x - r._physical_phase(ego, 3)
            expected = ego.x + max(-2, min(2, 0.3 * physical_error / 2)) / 0.3
            self.assertAlmostEqual(target, expected)
            targets.append(target)
        self.assertLess(abs(targets[1]-targets[0]), 0.001)

    def test_lane_center_physical_and_discrete_coordinates_are_identical(self):
        for lanes in (2, 3):
            for lane in range(lanes):
                ego = car(lane, 100, lane)
                self.assertAlmostEqual(r._physical_phase(ego, lanes), r._phase(lane, lanes))


if __name__ == "__main__":
    unittest.main(verbosity=2)
