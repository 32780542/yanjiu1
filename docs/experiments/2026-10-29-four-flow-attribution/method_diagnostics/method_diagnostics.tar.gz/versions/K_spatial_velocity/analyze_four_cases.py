"""Read-only K physical audit, reusing already audited J/H baseline metrics."""
from dataclasses import asdict
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

P=Path(__file__).resolve().parent
ROOT=P.parents[1]
MAIN=ROOT/'variants/phase5g_pure_formation'
sys.path.insert(0,str(MAIN))
from experiments.bottleneck_attribution import evaluate_case
from experiments.complete_layers import evaluate_layers
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=read(P/'candidate_manifest.json')
parent=read(P/'J_parent_manifest.json')
Hfreeze=read(ROOT/'tmp/head_group_H_release/freeze.json')
assert all(sha(P/n)==value for n,value in manifest['source_sha256'].items())
assert all(sha(ROOT/'tmp/J_spatial_phase'/n)==value for n,value in parent['source_sha256'].items())
assert all(sha(MAIN/n)==sha(ROOT/'tmp/head_group_H_release'/n)==value for n,value in Hfreeze['source_sha256'].items())

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
    return m
qdot=[]
for label,folder in [('H','head_group_H_release'),('J','J_spatial_phase'),('K','K_spatial_velocity')]:
    m=load('K_check_'+label,ROOT/'tmp'/folder/'noa/native_rules.py')
    a=m.Vehicle(0,820.,1.65,28.8,0);b=m.Vehicle(1,820.,4.95,28.8,1)
    heads=[]
    for car,peer,slope in [(a,b,1/24),(b,a,-1/24)]:
        speed,target,_=m._following(car,(peer,),2,**({} if label=='H' else {'drop_x':1000.}))
        desired=(speed-(1-m.SPEED_RELAXATION)*car.speed)/m.SPEED_RELAXATION
        heads.append(dict(lane=car.lane,physical_requested_speed=speed,target=target,
                          reconstructed_physical_desired_speed=desired,
                          desired_qdot_in_shared_J_K_field=desired*(1+slope)))
    qdot.append(dict(method=label,heads=heads))

base=P/'results/four_20261029T025926083350Z'
cases=read(base/'cases.json');assert len(cases)==4
old=read(ROOT/'tmp/J_spatial_phase/report.json')
rows=[]
for case in cases:
    seed,scenario=case['seed'],case['scenario']
    prior=next(row for row in old['pairs'] if row['seed']==seed and row['scenario']==scenario)
    path=Path(case['path']);result=read(path/'result.json');attribution=evaluate_case(path)
    regions={'upstream':(3,(0,640)),'downstream':(2,(1000,1200))} if scenario=='lane_drop' else {'straight':(3,(0,1200))}
    layers={key:evaluate_layers(path/'positions.jsonl.gz',lanes,region) for key,(lanes,region) in regions.items()}
    current=dict(path=str(path),result={key:result[key] for key in ['status','safe','requested','completed','collisions','teleports','mean_travel_time_s','fuel_g_per_km']},
        attribution={key:attribution[key] for key in ['attribution_eligible','audit_issues','mean_segment_100_600_s','mean_segment_640_1100_s','mean_segment_800_1100_s','region_mean_n','region_mean_speed_mps','region_low_speed_fraction','flow_1000m_veh_h']},layers=layers,
        positions_sha256=sha(path/'positions.jsonl.gz'),result_sha256=sha(path/'result.json'))
    assert current['attribution']['attribution_eligible']
    deltas={}
    for method in ['H','J']:
        earlier=prior[method];prior_path=Path(earlier['path'])
        assert read(path/'input.json')['arrivals']==read(prior_path/'input.json')['arrivals']
        assert read(path/'input.json')['physical']==read(prior_path/'input.json')['physical']
        if scenario=='straight3':
            with gzip.open(path/'positions.jsonl.gz','rb') as a,gzip.open(prior_path/'positions.jsonl.gz','rb') as b:
                while True:
                    x,y=a.read(1024*1024),b.read(1024*1024);assert x==y
                    if not x:break
        delta={key:current['attribution'][key]-earlier['attribution'][key]
               for key in ['mean_segment_100_600_s','mean_segment_640_1100_s','mean_segment_800_1100_s']}
        delta['mean_travel_time_s']=current['result']['mean_travel_time_s']-earlier['result']['mean_travel_time_s']
        deltas['K_minus_'+method]=delta
    row=dict(seed=seed,scenario=scenario,H=prior['H'],J=prior['J'],K=current,
             demand_and_physical_equal=True,straight_byte_equal=scenario=='straight3',**deltas)
    rows.append(row)
    print(json.dumps(dict(seed=seed,scenario=scenario,result=current['result'],**deltas)),flush=True)
report=dict(manifest=manifest,static_tests=dict(count=8,
    red=str(ROOT/'results/operations/20261029T025722812538Z_K-spatial-velocity-physical-invariant-red_0e2f8894'),
    green=str(ROOT/'results/operations/20261029T025828674367Z_K-spatial-velocity-physical-invariant-green_cb4cac99')),
    zero_q_pair_desired_qdot=qdot,six=read(P/'six_summary.json'),pairs=rows,
    main_J_H_sources_unchanged=True,baseline_metric_provenance=str(ROOT/'tmp/J_spatial_phase/report.json'),
    method='Only actual mutually selected free-head pairs use physical desired=(CRUISE+phase_speed)/(1+dpdx), with dpdx=(physical_phase2-physical_phase3)/360 strictly640<x<1000; unmatched cars keep slope0. Existing request damping, speed/safety caps, same-lane-front following, J geometry/pair weights, lateral join and all parameters/Memory remain unchanged.',
    limitations='The invariant concerns reconstructed desired qdot before original rho=.2 damping; it is not instantaneous physical equality or a total-system zero-sum law. Neither J stability failure nor original upstream cost is wholly attributed to this term. Two seeds and six-car gates are not a full-matrix method-success claim. No further condition, parameter search or patch stacking.')
with (P/'report.json').open('x',encoding='utf-8') as out:json.dump(report,out,indent=2);out.write('\n')
print(json.dumps(dict(report=str(P/'report.json'),cases=4,main_J_H_unchanged=True)),flush=True)
