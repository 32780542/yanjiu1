from dataclasses import asdict, replace
import importlib.util
from pathlib import Path
import random
import sys
import unittest

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE))
from noa import native_rules as r
spec=importlib.util.spec_from_file_location('K_J_reference',PACKAGE.parent/'J_spatial_phase/noa/native_rules.py')
J=importlib.util.module_from_spec(spec);sys.modules[spec.name]=J;spec.loader.exec_module(J)


class SpatialVelocityTests(unittest.TestCase):
    def car(self,x,lane,track=0,speed=28.8):
        return r.Vehicle(track,x,(lane+.5)*3.3,speed,lane)

    def desired(self,speed,ego):
        return (speed-(1-r.SPEED_RELAXATION)*ego.speed)/r.SPEED_RELAXATION

    def test_zero_q_error_pair_has_common_desired_qdot_even_when_error_is_zero(self):
        a,b=self.car(820,0),self.car(820,1,1)
        self.assertAlmostEqual(a.x+r._formation_phase(a,2,1000),b.x+r._formation_phase(b,2,1000))
        for ego,peer,slope in [(a,b,1/24),(b,a,-1/24)]:
            speed,target,reference=r._following(ego,(peer,),2,drop_x=1000.)
            self.assertAlmostEqual(target,ego.x)
            self.assertIsNone(reference)
            desired=self.desired(speed,ego)
            self.assertLess(desired,r.MAX_SPEED)
            self.assertAlmostEqual(desired*(1+slope),r.CRUISE)

    def test_nonzero_phase_error_is_converted_with_the_same_jacobian(self):
        ego,peer=self.car(820,0),self.car(830,1,1)
        speed,target,_=r._following(ego,(peer,),2,drop_x=1000.)
        self.assertAlmostEqual(target-ego.x,4.6)
        self.assertAlmostEqual(self.desired(speed,ego)*(25/24),30.2375)

    def test_isolated_vehicle_inside_preparation_keeps_physical_cruise(self):
        for lane in range(3):
            ego=self.car(820,lane)
            speed,target,reference=r._following(ego,(),2 if lane<2 else 3,drop_x=1000.)
            self.assertEqual((speed,target,reference),(r.CRUISE,ego.x,None))

    def test_nonmutual_nearby_head_does_not_enable_coordinate_feedforward(self):
        ego=self.car(820,0);peer=self.car(780,1,1);alternative=self.car(765,0,2)
        speed,target,reference=r._following(ego,(peer,alternative),2,drop_x=1000.)
        self.assertEqual((speed,target,reference),(r.CRUISE,ego.x,None))

    def test_actual_same_lane_front_branch_matches_J_exactly(self):
        ego,front,peer=self.car(820,0),self.car(865,0,1,26.8),self.car(820,1,2)
        expected=J._following(J.Vehicle(**asdict(ego)),tuple(J.Vehicle(**asdict(c)) for c in [front,peer]),2,drop_x=1000.)
        actual=r._following(ego,(front,peer),2,drop_x=1000.)
        self.assertEqual(actual,expected)
        self.assertEqual(actual[1],front.x-r.GAP)
        self.assertEqual(actual[2],front.track)

    def test_outside_and_exact_boundaries_keep_J_following(self):
        for x,lanes in [(400.,3),(640.,2),(1000.,2),(1100.,2)]:
            ego,peer=self.car(x,0),self.car(x+12,1,1)
            actual=r._following(ego,(peer,),lanes,drop_x=1000.)
            expected=J._following(J.Vehicle(**asdict(ego)),(J.Vehicle(**asdict(peer)),),lanes,drop_x=1000.)
            self.assertEqual(actual,expected)

    def test_formation_noa_and_straight_transform_remain_J_equivalent(self):
        rng=random.Random(111)
        for mode,drop in [('formation',1000.),('noa',1000.),('transform',None)]:
            for _ in range(80):
                ego=self.car(rng.uniform(300,1100),rng.randrange(3))
                rows=tuple(self.car(ego.x+rng.uniform(-100,200),rng.randrange(3),i+1) for i in range(7))
                command,memory=r.decide(ego,rows,r.Memory(),mode,drop)
                prior,prior_memory=J.decide(J.Vehicle(**asdict(ego)),tuple(J.Vehicle(**asdict(c)) for c in rows),J.Memory(),mode,drop)
                self.assertEqual((asdict(command),asdict(memory)),(asdict(prior),asdict(prior_memory)))

    def test_actual_lateral_execution_keeps_join_speed_and_memory(self):
        ego=replace(self.car(820,1),y=6.0,vy=3.3,pending_lane=2)
        rows=(self.car(860,2,1),self.car(790,2,2))
        memory=r.Memory(lane_target=2,joining=True)
        command,updated=r.decide(ego,rows,memory,'transform',1000.)
        prior,prior_memory=J.decide(J.Vehicle(**asdict(ego)),tuple(J.Vehicle(**asdict(c)) for c in rows),J.Memory(**asdict(memory)),'transform',1000.)
        self.assertEqual(command.reason,'executing')
        self.assertEqual((asdict(command),asdict(updated)),(asdict(prior),asdict(prior_memory)))


if __name__=='__main__':unittest.main()
