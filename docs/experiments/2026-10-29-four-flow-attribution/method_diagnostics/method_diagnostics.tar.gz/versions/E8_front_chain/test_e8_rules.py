"""E8 behavioral regressions, first run against the untouched copied D rules."""
import unittest

from noa import native_rules as r


def car(track, x, lane, speed=28.8):
    return r.Vehicle(track, x, (lane + 0.5) * 3.3, speed, lane)


class E8RulesTests(unittest.TestCase):
    def test_visible_front_outside_large_component_remains_the_reference(self):
        ego = car(0, 100.0, 0)
        front = car(1, 200.0, 0, 23.0)
        others = (front, car(2, 105, 1), car(3, 110, 2), car(4, 115, 1), car(5, 120, 2), car(6, 125, 1))
        component = r._component(ego, others)
        self.assertGreaterEqual(len(component), 6)
        self.assertNotIn(front, component)
        speed, target, reference = r._following(ego, others, 3)
        self.assertEqual(reference, front.track)
        self.assertEqual(target, 170.0)
        self.assertAlmostEqual(speed, r._request(ego, 170.0, front.speed))

    def test_visible_front_outside_short_component_has_no_special_cruise_cap(self):
        ego = car(0, 100.0, 0)
        front = car(1, 200.0, 0, 23.0)
        speed, target, reference = r._following(ego, (front,), 3)
        self.assertEqual(reference, front.track)
        self.assertEqual(target, 170.0)
        self.assertAlmostEqual(speed, r._request(ego, 170.0, front.speed))

    def test_aligned_slow_follower_uses_the_real_front_speed(self):
        ego = car(0, 100.0, 0, 24.0)
        front = car(1, 130.0, 0, 24.0)
        self.assertAlmostEqual(r._following(ego, (front,), 3)[0], 24.0)

    def check_receiving(self, incoming_speed):
        cars = (car(0, 700, 2), car(1, 670, 2, incoming_speed), car(2, 685, 1), car(3, 655, 1), car(4, 700, 0), car(5, 670, 0))
        ego = cars[3]
        rows = tuple(c for c in cars if c.track != ego.track)
        command, _ = r._decide(ego, rows, r.Memory(), "transform", 1000.0)
        self.assertEqual(command.reason, "open_gap")
        extra = max(0.0, ego.speed ** 2 - incoming_speed ** 2) / 20.0
        distance = max(8.0, 4.0 + 1.5 + 0.2 * ego.speed + extra)
        self.assertAlmostEqual(command.target_x, 670.0 - distance)
        return command

    def test_receiving_equal_speed_uses_insertion_distance_not_formation_spacing(self):
        command = self.check_receiving(28.8)
        self.assertAlmostEqual(command.speed, 28.8)

    def test_receiving_slower_incoming_reserves_stopping_distance(self):
        self.check_receiving(20.0)

    def test_receiving_faster_incoming_does_not_use_negative_stopping_reserve(self):
        self.check_receiving(33.3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
