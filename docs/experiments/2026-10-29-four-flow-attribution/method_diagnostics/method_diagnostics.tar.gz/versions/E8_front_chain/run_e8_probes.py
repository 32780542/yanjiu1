"""Frozen E8 gates followed by the authorized four 600 s flow probes."""
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import sys

package = Path(__file__).resolve().parent
root = package.parents[1]
sys.path.insert(0, str(package))
from experiments.native_sumo import run_case
from experiments.complete_layers import evaluate_layers, groups_at


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


base = json.loads((package / "base_manifest.json").read_text(encoding="utf-8"))
variant = Path(base["source_root"])
frozen = {relative: sha(package / relative) for relative in base["source_sha256"]}
for relative, digest in base["source_sha256"].items():
    assert sha(variant / relative) == digest, ("main changed before probe", relative)
    if relative != "noa/native_rules.py":
        assert frozen[relative] == digest, ("unexpected isolated source change", relative)
write(package / "candidate_manifest.json", dict(source_sha256=frozen, base_source_sha256=base["source_sha256"]))
diff = "".join(difflib.unified_diff((variant / "noa/native_rules.py").read_text(encoding="utf-8").splitlines(True), (package / "noa/native_rules.py").read_text(encoding="utf-8").splitlines(True), fromfile="main_pending_fixed/native_rules.py", tofile="E8_front_chain/native_rules.py"))
(package / "candidate.diff").write_text(diff, encoding="utf-8")
summary = dict(package=str(package), candidate_source_sha256=frozen, records=[], status="running", tests=dict(red_operation="20261029T014538711081Z_E8-front-chain-red_662a15d2", red_failures=5, green_operation="20261029T014604908448Z_E8-front-chain-green_d3dcaabb", green_tests=6))


def save():
    write(package / "probe_summary.json", summary)


def first_full(path, lanes, region):
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        for line in stream:
            frame = json.loads(line)
            states = {key: value for key, value in frame["states"].items() if region[0] <= value[0] < region[1]}
            groups = groups_at(states, lanes)
            if any(g["size"] == 6 and g["layer_count"] >= 2 for g in groups):
                return dict(time_s=frame["time_s"], groups=groups)
    return None


def run(label, *, mode="transform", scenario="lane_drop", flow=1250.0, initial=None, diagnostic=False):
    directory = run_case(mode=mode, scenario=scenario, seed=1, flow=flow, duration=1.0 if initial is not None else 600.0, max_time=100.0 if initial is not None else 900.0, initial=initial, diagnostic=diagnostic, output_base=package / "results")
    result = json.loads((directory / "result.json").read_text(encoding="utf-8"))
    assert result["source_sha256"] == frozen
    for relative, digest in frozen.items():
        assert sha(directory / "source" / relative) == digest
        assert sha(package / relative) == digest
    layers = dict(upstream=evaluate_layers(directory / "positions.jsonl.gz", 3, region=(100.0, 640.0)))
    if scenario == "lane_drop":
        layers["downstream"] = evaluate_layers(directory / "positions.jsonl.gz", 2, region=(1000.0, 1200.0))
    else:
        layers["straight_100_1000"] = evaluate_layers(directory / "positions.jsonl.gz", 3, region=(100.0, 1000.0))
    record = dict(label=label, case_dir=str(directory), mode=mode, scenario=scenario, flow=flow, initial=initial, result=result, layers=layers, source_snapshots_verified=6)
    if initial is not None:
        lanes, region = (2, (1000.0, 1200.0)) if scenario == "lane_drop" else (3, (100.0, 1000.0))
        record["first_full_six"] = first_full(directory / "positions.jsonl.gz", lanes, region)
    summary["records"].append(record)
    save()
    print(json.dumps(dict(label=label, case_dir=str(directory), status=result["status"], safe=result["safe"], completed=result["completed"], requested=result["requested"], tt=result["mean_travel_time_s"], fuel=result["fuel_g_per_km"], lane_change_completions=result["lane_change_completions"], layers={name: {key: value[key] for key in ("formation_participation_rate", "peak_multilayer_size", "stable_participation_rate")} for name, value in layers.items()}, first_full_six_s=record.get("first_full_six", {}).get("time_s") if record.get("first_full_six") else None)), flush=True)
    return record


def gate(record, name):
    result = record["result"]
    measured = record["layers"][name]
    passed = result["safe"] and result["all_completed"] and result["completed"] == 6 and measured["peak_multilayer_size"] == 6 and measured["formation_participation_rate"] > 0 and record["first_full_six"] is not None
    record["gate_passed"] = passed
    if not passed:
        summary["status"] = "gate_failed_no_flow_runs"
        summary["failed_gate"] = record["label"]
        save()
        print(json.dumps(dict(stopped=True, reason="physical six-car gate failed", gate=record["label"])), flush=True)
        raise SystemExit(2)


original = json.loads((root / "docs/experiments/2026-10-29-native-pd-final/six_vehicle_initial.json").read_text(encoding="utf-8"))
write(package / "six_vehicle_transform_initial.json", original)
transform = run("original_six_transform", initial=original, diagnostic=True)
gate(transform, "downstream")
scrambled = [dict(id=f"scramble_L{lane}_{index}", depart=0.0, lane=lane, x=x, speed=28.8) for lane, positions in ((2, (100.0, 62.0)), (1, (89.0, 41.0)), (0, (111.0, 78.0))) for index, x in enumerate(positions)]
states = {r["id"]: (r["x"], (r["lane"] + 0.5) * 3.3, r["speed"], 0.0) for r in scrambled}
summary["scrambled_initial_groups"] = groups_at(states, 3)
assert not any(g["size"] == 6 for g in summary["scrambled_initial_groups"])
write(package / "six_vehicle_scrambled_initial.json", scrambled)
for mode in ("formation", "transform"):
    record = run(f"scrambled_six_straight_{mode}", mode=mode, scenario="straight3", initial=scrambled, diagnostic=True)
    gate(record, "straight_100_1000")
summary["six_car_gates_passed"] = True
save()
for flow in (500.0, 1500.0):
    for scenario in ("straight3", "lane_drop"):
        run(f"q{int(flow)}_{scenario}_transform_600s", flow=flow, scenario=scenario)
summary["main_sources_unchanged"] = {relative: sha(variant / relative) == digest for relative, digest in base["source_sha256"].items()}
summary["status"] = "completed"
save()
print(json.dumps(dict(status=summary["status"], summary=str(package / "probe_summary.json"), cases=len(summary["records"]), main_sources_unchanged=summary["main_sources_unchanged"])), flush=True)
