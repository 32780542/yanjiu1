"""Summarize frozen E11 evidence without rerunning or modifying simulations."""
import ast
import gzip
import hashlib
import json
from pathlib import Path

package = Path(__file__).resolve().parent
r = json.loads((package / "probe_summary.json").read_text(encoding="utf-8"))
base = json.loads((package / "base_manifest.json").read_text(encoding="utf-8"))
assert r["status"] == "completed" and len(r["records"]) == 6
assert all(r["main_sources_unchanged"].values()) and all(r["E10_sources_unchanged"].values()) and all(r["configs_unchanged"].values())
brief = {key: r[key] for key in ("package", "status", "candidate_source_sha256", "main_sources_unchanged", "E10_sources_unchanged", "configs_unchanged", "tests", "gate_policy", "both_six_car_gates_passed")}
brief["operation"] = "20261029T020509820872Z_E11-actual-head-six-gates-four-flows_67d1a819"
brief["records"] = []
for row in r["records"]:
    result, case = row["result"], Path(row["case_dir"])
    out = {key: row[key] for key in ("label", "case_dir", "scenario", "flow")}
    out.update({key: result[key] for key in ("safe", "all_completed", "status", "requested", "completed", "mean_entry_wait_s", "mean_travel_time_s", "mean_system_time_s", "fuel_g_per_km", "collisions", "teleports", "lane_change_completions")})
    out["layers"] = {zone: {key: layer[key] for key in ("formation_participation_rate", "stable_participation_rate", "peak_multilayer_size", "mean_multilayer_size")} for zone, layer in row["layers"].items()}
    out["first_full_six_s"] = None if not row.get("first_full_six") else row["first_full_six"]["time_s"]
    out["full_six_gate_passed"] = row.get("full_six_gate_passed")
    if row["initial"] is None:
        previous = None
        vehicle_s = overspeed_s = excess_m = speed_s = 0.0
        with gzip.open(case / "positions.jsonl.gz", "rt", encoding="utf-8") as stream:
            for line in stream:
                frame = json.loads(line)
                if previous is not None:
                    dt = frame["time_s"] - previous["time_s"]
                    for state in previous["states"].values():
                        if 100 <= state[0] < 1000:
                            v = state[2]
                            vehicle_s += dt
                            speed_s += v * dt
                            excess_m += max(0.0, v - 28.8) * dt
                            if v > 28.8 + 1e-6:
                                overspeed_s += dt
                previous = frame
        out["speed_diagnostic_100_1000"] = dict(mean_mps=speed_s / vehicle_s if vehicle_s else None, overspeed_vehicle_s=overspeed_s, overspeed_vehicle_s_fraction=overspeed_s / vehicle_s if vehicle_s else None, positive_speed_excess_integral_m=excess_m, method="left-held .1s trajectory; v>28.8+1e-6; positive excess is not a bottleneck benefit")
    brief["records"].append(out)
brief["paired_TF_drop_minus_straight_full_trip_s"] = {str(flow): next(x["mean_travel_time_s"] for x in brief["records"] if x["flow"] == flow and x["scenario"] == "lane_drop" and x["label"].startswith("q")) - next(x["mean_travel_time_s"] for x in brief["records"] if x["flow"] == flow and x["scenario"] == "straight3" and x["label"].startswith("q")) for flow in (500.0, 1500.0)}
for relative, digest in brief["candidate_source_sha256"].items():
    assert hashlib.sha256((package / relative).read_bytes()).hexdigest() == digest
source = Path(base["source_root"])
def functions(path):
    return {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(path.read_text(encoding="utf-8")).body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
before, after = functions(source / "noa/native_rules.py"), functions(package / "noa/native_rules.py")
changed = [name for name in before.keys() | after.keys() if before.get(name) != after.get(name)]
assert changed == ["_following"], changed
brief["changed_top_level_functions_vs_E10"] = changed
brief["all_cases_safe_completed"] = all(x["safe"] and x["all_completed"] for x in brief["records"])
brief["limitation"] = "Only one seed at two flow levels; paired NOA and full four-flow attribution are still required. Six-car formation/transform gates do not establish continuous-flow traffic benefits."
(package / "brief_summary.json").write_text(json.dumps(brief, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(status=brief["status"], all_safe=brief["all_cases_safe_completed"], summary=str(package / "brief_summary.json"), TF_drop_minus_straight=brief["paired_TF_drop_minus_straight_full_trip_s"], cases=[dict(label=x["label"], tt=x["mean_travel_time_s"], P={k: v["formation_participation_rate"] for k, v in x["layers"].items()}, peak={k: v["peak_multilayer_size"] for k, v in x["layers"].items()}, speed=x.get("speed_diagnostic_100_1000")) for x in brief["records"]])))
