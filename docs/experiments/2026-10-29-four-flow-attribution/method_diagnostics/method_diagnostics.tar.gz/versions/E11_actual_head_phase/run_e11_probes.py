"""Frozen E11 actual-head topology: both six-car gates before four flow probes."""
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import sys

package = Path(__file__).resolve().parent
root = package.parents[1]
sys.path.insert(0, str(package))
from experiments.native_sumo import run_case
from experiments.complete_layers import evaluate_layers, groups_at


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


base = json.loads((package / "base_manifest.json").read_text(encoding="utf-8"))
source = Path(base["source_root"])
main = Path(base["main_root"])
frozen = {relative: sha(package / relative) for relative in base["source_sha256"]}
for relative, digest in base["source_sha256"].items():
    assert sha(source / relative) == digest, ("E10 frozen source changed", relative)
    if relative != "noa/native_rules.py":
        assert frozen[relative] == digest, ("unexpected core source edit", relative)
for relative, digest in base["configs_sha256"].items():
    assert sha(package / relative) == digest
write(package / "candidate_manifest.json", dict(status="frozen", source_sha256=frozen, base_source_sha256=base["source_sha256"], configs_sha256=base["configs_sha256"], authorized_changes=["replace body mutual phase with actual-head mutual phase only", "head mutual radius50m; gains unchanged"]))
(package / "candidate.diff").write_text("".join(difflib.unified_diff((source / "noa/native_rules.py").read_text(encoding="utf-8").splitlines(True), (package / "noa/native_rules.py").read_text(encoding="utf-8").splitlines(True), fromfile="E10_frozen/native_rules.py", tofile="E11_actual_head_phase/native_rules.py")), encoding="utf-8")
summary = dict(package=str(package), candidate_source_sha256=frozen, records=[], status="running", tests=dict(red_operation="20261029T020330677206Z_E11-actual-head-phase-red_5bd207b7", red_failures=5, green_operation="20261029T020408577924Z_E11-actual-head-phase-green_64e721b3", green_tests=8), gate_policy="flow probes require BOTH original-six drop full-six recovery and scrambled straight full-six formation")


def save():
    write(package / "probe_summary.json", summary)


def first_full(path, lanes, region):
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        for line in stream:
            frame = json.loads(line)
            states = {key: value for key, value in frame["states"].items() if region[0] <= value[0] < region[1]}
            groups = groups_at(states, lanes)
            if any(g["size"] == 6 and g["layer_count"] >= 2 for g in groups):
                return dict(time_s=frame["time_s"], groups=groups)
    return None


def run(label, *, scenario="lane_drop", flow=1250.0, initial=None):
    directory = run_case(mode="transform", scenario=scenario, seed=1, flow=flow, duration=1.0 if initial is not None else 600.0, max_time=100.0 if initial is not None else 900.0, initial=initial, diagnostic=initial is not None, output_base=package / "results")
    result = json.loads((directory / "result.json").read_text(encoding="utf-8"))
    assert result["source_sha256"] == frozen
    for relative, digest in frozen.items():
        assert sha(directory / "source" / relative) == digest
        assert sha(package / relative) == digest
    layers = dict(upstream=evaluate_layers(directory / "positions.jsonl.gz", 3, region=(100.0, 640.0)))
    if scenario == "lane_drop":
        layers["downstream"] = evaluate_layers(directory / "positions.jsonl.gz", 2, region=(1000.0, 1200.0))
    else:
        layers["straight_100_1000"] = evaluate_layers(directory / "positions.jsonl.gz", 3, region=(100.0, 1000.0))
    record = dict(label=label, case_dir=str(directory), scenario=scenario, flow=flow, initial=initial, result=result, layers=layers, source_snapshots_verified=6)
    if initial is not None:
        name = "downstream" if scenario == "lane_drop" else "straight_100_1000"
        lanes, region = (2, (1000.0, 1200.0)) if scenario == "lane_drop" else (3, (100.0, 1000.0))
        record["first_full_six"] = first_full(directory / "positions.jsonl.gz", lanes, region)
        measured = layers[name]
        record["full_six_gate_passed"] = bool(result["safe"] and result["all_completed"] and result["completed"] == 6 and measured["peak_multilayer_size"] == 6 and measured["formation_participation_rate"] > 0 and record["first_full_six"] is not None)
    summary["records"].append(record)
    save()
    print(json.dumps(dict(label=label, case_dir=str(directory), status=result["status"], safe=result["safe"], completed=result["completed"], requested=result["requested"], tt=result["mean_travel_time_s"], fuel=result["fuel_g_per_km"], lane_change_completions=result["lane_change_completions"], layers={name: {key: value[key] for key in ("formation_participation_rate", "peak_multilayer_size", "stable_participation_rate")} for name, value in layers.items()}, first_full_six_s=record.get("first_full_six", {}).get("time_s") if record.get("first_full_six") else None, full_six_gate_passed=record.get("full_six_gate_passed"))), flush=True)
    return record


original = json.loads((root / "docs/experiments/2026-10-29-native-pd-final/six_vehicle_initial.json").read_text(encoding="utf-8"))
write(package / "six_vehicle_transform_initial.json", original)
transformed = run("original_six_transform", initial=original)
scrambled = [dict(id=f"scramble_L{lane}_{index}", depart=0.0, lane=lane, x=x, speed=28.8) for lane, positions in ((2, (100.0, 62.0)), (1, (89.0, 41.0)), (0, (111.0, 78.0))) for index, x in enumerate(positions)]
states = {r["id"]: (r["x"], (r["lane"] + 0.5) * 3.3, r["speed"], 0.0) for r in scrambled}
summary["scrambled_initial_groups"] = groups_at(states, 3)
assert not any(g["size"] == 6 for g in summary["scrambled_initial_groups"])
write(package / "six_vehicle_scrambled_initial.json", scrambled)
formed = run("scrambled_six_straight_transform", scenario="straight3", initial=scrambled)
if not (formed["full_six_gate_passed"] and transformed["full_six_gate_passed"]):
    summary["status"] = "six_car_gate_failed_no_flow_runs"
    save()
    raise SystemExit(2)
summary["both_six_car_gates_passed"] = True
save()
for flow in (500.0, 1500.0):
    for scenario in ("straight3", "lane_drop"):
        run(f"q{int(flow)}_{scenario}_transform_600s", flow=flow, scenario=scenario)
summary["E10_sources_unchanged"] = {relative: sha(source / relative) == digest for relative, digest in base["source_sha256"].items()}
summary["main_sources_unchanged"] = {relative: sha(main / relative) == digest for relative, digest in base["main_source_sha256"].items()}
summary["configs_unchanged"] = {relative: sha(package / relative) == digest for relative, digest in base["configs_sha256"].items()}
summary["status"] = "completed"
save()
print(json.dumps(dict(status=summary["status"], summary=str(package / "probe_summary.json"), cases=len(summary["records"]), main_sources_unchanged=all(summary["main_sources_unchanged"].values()), E10_sources_unchanged=all(summary["E10_sources_unchanged"].values()))), flush=True)
