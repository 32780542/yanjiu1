from dataclasses import replace
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from noa import native_rules as r


class LocalPairPhaseTests(unittest.TestCase):
    def car(self, track, x, lane, speed=28.8):
        return r.Vehicle(track, x, (lane + .5)*r.LANE_WIDTH, speed, lane)

    def test_perfect_lattice_with_unequal_window_heads_stays_at_cruise(self):
        for lane in range(3):
            with self.subTest(lane=lane):
                ego=self.car(0,100-r._phase(lane,3),lane)
                rows=tuple(self.car(10*j+i, q-r._phase(j,3),j)
                           for j in range(3) if j!=lane for i,q in enumerate([70,100,130,160]))
                speed,target,reference=r._following(ego,rows,3)
                self.assertAlmostEqual(speed,r.CRUISE)
                self.assertAlmostEqual(target,ego.x)
                self.assertIsNone(reference)

    def test_mutual_pair_phase_corrections_are_equal_and_opposite_and_damped(self):
        left=self.car(0,100,0);middle=self.car(1,90,1)
        a=r._following(left,(middle,),3)[0]-r.CRUISE
        b=r._following(middle,(left,),3)[0]-r.CRUISE
        self.assertGreater(a,0);self.assertLess(b,0)
        self.assertAlmostEqual(a,-b)
        self.assertAlmostEqual(a,.15)

    def test_real_same_lane_front_is_never_ignored_for_a_large_component(self):
        ego=self.car(0,100,0);front=self.car(1,250,0,16)
        rows=(front,)+tuple(self.car(10*j+i,x,j) for j,xs in [(1,[85,115,145,175]),(2,[100,130,160])]
                           for i,x in enumerate(xs))
        speed,target,reference=r._following(ego,rows,3)
        self.assertEqual(reference,front.track)
        self.assertAlmostEqual(target,220)
        self.assertAlmostEqual(speed,r._request(ego,220,front.speed))

    def test_free_vehicle_uses_damped_cruise_anchor(self):
        ego=self.car(0,100,0,20)
        speed,target,reference=r._following(ego,(),3)
        self.assertEqual(target,ego.x)
        self.assertAlmostEqual(speed,r._request(ego,ego.x,r.CRUISE))

    def test_nearer_alternative_prevents_nonmutual_pair_coupling(self):
        ego=self.car(0,100,0);peer=self.car(1,90,1);alternative=self.car(2,104,0)
        _,target,reference=r._following(ego,(peer,alternative),3)
        self.assertEqual(reference,alternative.track)
        self.assertEqual(target,alternative.x-r.GAP)

    def test_track_permutation_does_not_choose_a_phase_peer(self):
        ego=self.car(0,100,0);rows=(self.car(1,70,1),self.car(2,100,1))
        a=r._following(ego,rows,3)[:2]
        b=r._following(ego,tuple(replace(c,track=99-c.track) for c in reversed(rows)),3)[:2]
        self.assertEqual(a,b)

    def test_inverse_gipps_receiving_uses_speed_difference_and_eight_meter_floor(self):
        self.assertTrue(hasattr(r,'_receiving_distance'))
        ego=self.car(0,700,1);incoming=self.car(1,715,2)
        self.assertAlmostEqual(r._receiving_distance(ego,incoming),11.26)
        self.assertEqual(r._receiving_distance(replace(ego,speed=0),incoming),8)
        incoming=replace(incoming,speed=10)
        self.assertAlmostEqual(r._receiving_distance(ego,incoming),11.26+(28.8**2-10**2)/20)


if __name__=='__main__':unittest.main()
