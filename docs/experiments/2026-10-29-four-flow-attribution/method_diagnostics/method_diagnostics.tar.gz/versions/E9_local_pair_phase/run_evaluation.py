"""One frozen eight-case E9 evaluation; independent CLI processes, no retries."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

PACKAGE = Path(__file__).resolve().parent
BASE = PACKAGE / "results" / ("flow_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
BASE.mkdir(exist_ok=False)
NAMES = json.loads((PACKAGE / "baseline_sha256.json").read_text(encoding="utf-8"))
FROZEN = {name:hashlib.sha256((PACKAGE/name).read_bytes()).hexdigest() for name in NAMES}
(BASE/"protocol.json").write_text(json.dumps(dict(flow=[500,1500], scenarios=["straight3","lane_drop"],
    modes=["formation","transform"], seed=1, duration=600, max_time=900, workers=4,
    source_sha256=FROZEN),indent=2),encoding="utf-8")


def run(flow, scenario, mode):
    label=f"q{flow}_{scenario}_{mode}"
    out=BASE/label
    args=[sys.executable,"-B",str(PACKAGE/"run_native_flow.py"),"--flow",str(flow),"--seed","1",
          "--scenario",scenario,"--mode",mode,"--duration","600","--max-time","900",
          "--output-base",str(out)]
    with (BASE/(label+".stdout.log")).open("w",encoding="utf-8") as stdout, (BASE/(label+".stderr.log")).open("w",encoding="utf-8") as stderr:
        completed=subprocess.run(args,stdout=stdout,stderr=stderr,timeout=300)
    directories=list(out.iterdir())
    assert completed.returncode==0 and len(directories)==1
    case=directories[0]
    result=json.loads((case/"result.json").read_text(encoding="utf-8"))
    assert result["source_sha256"]==FROZEN
    return dict(label=label,path=str(case),flow=flow,scenario=scenario,mode=mode,
                result={key:result[key] for key in ["status","safe","requested","departed","completed",
                  "collisions","teleports","actual_end_s","mean_travel_time_s","all_fuel_mg",
                  "fuel_g_per_km","lane_changes","lane_change_completions"]})


rows=[]
with ThreadPoolExecutor(max_workers=4) as pool:
    futures=[pool.submit(run,flow,scenario,mode) for flow in [500,1500]
             for scenario in ["straight3","lane_drop"] for mode in ["formation","transform"]]
    for future in as_completed(futures):
        row=future.result();rows.append(row)
        (BASE/"cases.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8")
        print(json.dumps(row),flush=True)
assert FROZEN=={name:hashlib.sha256((PACKAGE/name).read_bytes()).hexdigest() for name in NAMES}
print(json.dumps(dict(output=str(BASE),cases=len(rows),source_unchanged=True)),flush=True)
