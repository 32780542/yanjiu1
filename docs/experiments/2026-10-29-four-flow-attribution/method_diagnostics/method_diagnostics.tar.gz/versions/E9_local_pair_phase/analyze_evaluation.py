"""Read-only physical metrics and source audit for the frozen E9 short round."""
import ast
import gzip
import hashlib
import json
from pathlib import Path

from experiments.complete_layers import evaluate_layers

PACKAGE = Path(__file__).resolve().parent
ROOT = PACKAGE.parents[1]
MAIN = ROOT / "variants/phase5g_pure_formation"
BASE = PACKAGE / "results/flow_20261029T015103344140Z"
rows = json.loads((BASE/"cases.json").read_text(encoding="utf-8"))
assert len(rows) == 8
manifest = json.loads((PACKAGE/"candidate_manifest.json").read_text(encoding="utf-8"))
baseline = json.loads((PACKAGE/"baseline_sha256.json").read_text(encoding="utf-8"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert all(sha(PACKAGE/name) == expected for name,expected in manifest["source_sha256"].items())
assert all(sha(MAIN/name) == expected for name,expected in baseline.items())
for row in rows:
    trace = Path(row["path"])/"positions.jsonl.gz"
    regions = {"upstream":(3,(0,640)), "downstream":(2,(1000,1200))} if row["scenario"]=="lane_drop" else {"straight":(3,(0,1200))}
    row["metrics"] = {name:evaluate_layers(trace,lanes,region) for name,(lanes,region) in regions.items()}
    print(json.dumps(dict(label=row["label"],metrics={name:{key:value[key] for key in
       ["formation_participation_rate","stable_participation_rate","peak_multilayer_size","internal_relation_breaks"]}
       for name,value in row["metrics"].items()})),flush=True)
pairs = {}
for flow in (500,1500):
    selected = {row["mode"]:row for row in rows if row["flow"]==flow and row["scenario"]=="straight3"}
    def physical_hash(row):
        digest=hashlib.sha256()
        with gzip.open(Path(row["path"])/"positions.jsonl.gz","rb") as stream:
            for block in iter(lambda:stream.read(1024*1024),b""):digest.update(block)
        return digest.hexdigest()
    pairs[str(flow)] = dict(straight_physical_TF_equal=physical_hash(selected["formation"])==physical_hash(selected["transform"]))
assert all(p["straight_physical_TF_equal"] for p in pairs.values())
old = {x.name:ast.dump(x,include_attributes=False) for x in ast.parse((MAIN/"noa/native_rules.py").read_text(encoding="utf-8")).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
new = {x.name:ast.dump(x,include_attributes=False) for x in ast.parse((PACKAGE/"noa/native_rules.py").read_text(encoding="utf-8")).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
changed = [name for name in new if new[name]!=old.get(name)]
assert changed == ["_following","_receiving_distance","_decide"]
report = dict(method="Mutual nearest real adjacent-lane phase peers within actual x+-90m. Geometry signed difference resolves ties. Fixed lanes-1 pair denominator. Same-lane actual front always sets reference and base gap; no-front cruise anchor. Phase desired-speed correction bounded2m/s and passed through existing request damping. Inverse-Gipps receiving; existing helper unchanged.",
    conclusion="Fails random-traffic formation objective: both straight flows and all upstream regions have zero confirmed multilayer participation. Scrambled-six success does not transfer to these random flows. Atq1500 drop transform is slower than formation. Retained unchanged; no corrective patch or parameter tuning.",
    source_manifest=manifest,main_six_unchanged=True,changed_rule_definitions=changed,
    tdd=dict(red=str(ROOT/"results/operations/20261029T014830979899Z_E9-local-pair-static-red_03a2451f"),
             green=str(ROOT/"results/operations/20261029T014906889737Z_E9-local-pair-static-green_304e8a97"),tests=7),
    six=json.loads((PACKAGE/"six_summary.json").read_text(encoding="utf-8")),cases=rows,pair_checks=pairs,
    limitations="Seed1 short round only. Original six started organized; only the scrambled straight case demonstrates formation from disorder. Original-six downstream confirmed peak4 is retained as incomplete six-car recovery. No parameter adjustment, patch stacking, main source edits or Git operations.")
(PACKAGE/"report.json").write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
print(json.dumps(dict(report=str(PACKAGE/"report.json"),cases=len(rows),main_six_unchanged=True,straight_TF_equal=pairs)),flush=True)
