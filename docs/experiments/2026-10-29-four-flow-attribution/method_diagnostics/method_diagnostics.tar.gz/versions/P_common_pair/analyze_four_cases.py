"""Read-only P calibration and rear-term ablation against frozen N/H/NOA."""
import gzip
import hashlib
import json
from pathlib import Path
import sys

P=Path(__file__).resolve().parent;ROOT=P.parents[1];MAIN=ROOT/'variants/phase5g_pure_formation'
sys.path.insert(0,str(MAIN))
from experiments.bottleneck_attribution import evaluate_case
from experiments.complete_layers import evaluate_layers
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=read(P/'candidate_manifest.json')
assert all(sha(P/n)==v for n,v in manifest['source_sha256'].items())
for folder in ['J_spatial_phase','K_spatial_velocity','N_common_pair_head']:
    m=read(ROOT/'tmp'/folder/'candidate_manifest.json')
    assert all(sha(ROOT/'tmp'/folder/n)==v for n,v in m['source_sha256'].items())
hfreeze=read(ROOT/'tmp/head_group_H_release/freeze.json')
assert all(sha(MAIN/n)==sha(ROOT/'tmp/head_group_H_release'/n)==v for n,v in hfreeze['source_sha256'].items())
baselines=read(ROOT/'tmp/N_common_pair_head/report.json')
bases=list((P/'results').glob('four_*'));assert len(bases)==1
cases=read(bases[0]/'cases.json');assert len(cases)==4
rows=[]
for case in cases:
    seed,scenario=case['seed'],case['scenario'];path=Path(case['path'])
    prior=next(r for r in baselines['pairs'] if r['seed']==seed and r['scenario']==scenario)
    result=read(path/'result.json');a=evaluate_case(path)
    regions={'upstream':(3,(0,640)),'downstream':(2,(1000,1200))} if scenario=='lane_drop' else {'straight':(3,(0,1200))}
    current=dict(path=str(path),result={k:result[k] for k in ['status','safe','requested','completed','collisions','teleports','mean_travel_time_s','fuel_g_per_km']},
        attribution={k:a[k] for k in ['attribution_eligible','audit_issues','mean_segment_100_600_s','mean_segment_640_1100_s','mean_segment_800_1100_s']},
        layers={key:evaluate_layers(path/'positions.jsonl.gz',lanes,region) for key,(lanes,region) in regions.items()},
        positions_sha256=sha(path/'positions.jsonl.gz'))
    deltas={}
    for label in ['H','NOA','N']:
        earlier=prior[label];ep=Path(earlier['path'])
        assert read(path/'input.json')['arrivals']==read(ep/'input.json')['arrivals']
        assert read(path/'input.json')['physical']==read(ep/'input.json')['physical']
        values={k:current['attribution'][k]-earlier['attribution'][k]
                if current['attribution'][k] is not None and earlier['attribution'][k] is not None else None
                for k in ['mean_segment_100_600_s','mean_segment_640_1100_s','mean_segment_800_1100_s']}
        values['mean_travel_time_s']=(current['result']['mean_travel_time_s']-earlier['result']['mean_travel_time_s']
                                   if current['result']['mean_travel_time_s'] is not None and earlier['result']['mean_travel_time_s'] is not None else None)
        deltas['P_minus_'+label]=values
    equal=None
    if scenario=='straight3':
        equal=True
        with gzip.open(path/'positions.jsonl.gz','rb') as x,gzip.open(Path(prior['H']['path'])/'positions.jsonl.gz','rb') as y:
            while True:
                aa,bb=x.read(1024*1024),y.read(1024*1024)
                if aa!=bb:equal=False;break
                if not aa:break
    row=dict(seed=seed,scenario=scenario,P=current,H=prior['H'],N=prior['N'],NOA=prior['NOA'],
             demand_and_physical_equal=True,straight_H_physical_byte_equal=equal,**deltas)
    rows.append(row);print(json.dumps(dict(seed=seed,scenario=scenario,result=current['result'],**deltas)),flush=True)
did=[]
for seed in [1,4]:
    straight=next(row for row in rows if row['seed']==seed and row['scenario']=='straight3')
    drop=next(row for row in rows if row['seed']==seed and row['scenario']=='lane_drop')
    did.append(dict(seed=seed,NOA_minus_P_drop_minus_straight={key:
        straight['P_minus_NOA'][key]-drop['P_minus_NOA'][key]
        if straight['P_minus_NOA'][key] is not None and drop['P_minus_NOA'][key] is not None else None
        for key in ['mean_segment_100_600_s','mean_segment_640_1100_s','mean_segment_800_1100_s']}))
report=dict(manifest=manifest,six=read(P/'six_summary.json'),pairs=rows,diagnostic_DID=did,
    static_tests=dict(count=9,red=str(ROOT/'results/operations/20261029T032543731879Z_P-remove-rear-assistance-static-red_86c70def'),green=str(ROOT/'results/operations/20261029T032608925477Z_P-common-pair-static-green_7365bf8f')),
    main_H_J_K_N_sources_unchanged=True,
    scope='Remove only N positive-rear speed assistance. Retain symmetric common discrete pair phase/nearest/weights; body follows actual front and head cruise reference is CRUISE. No J/K spatial field, gain change, additional fallback or Memory field.',
    limitations='Calibration seeds1/4 only; baseline N/H/NOA metrics are diagnostic, not a same-freeze final matrix. Root independent acceptance requires new seeds6-10 across all four flows and paired same-overtaking C1. A geometric consistency fix does not imply a travel advantage or method success. All results retained; no further conditions or parameter search.')
with (P/'report.json').open('x',encoding='utf-8') as out:json.dump(report,out,indent=2);out.write('\n')
print(json.dumps(dict(report=str(P/'report.json'),DID=did)),flush=True)
