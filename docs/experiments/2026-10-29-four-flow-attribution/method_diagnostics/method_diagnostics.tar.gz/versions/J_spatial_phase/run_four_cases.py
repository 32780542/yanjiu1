"""Frozen J: q1500, seeds1/4, transform straight/drop; no retries."""
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

from experiments.native_sumo import run_case

PACKAGE=Path(__file__).resolve().parent


def task(parameters):
    directory=run_case(**parameters)
    result=json.loads((directory/'result.json').read_text(encoding='utf-8'))
    return dict(path=str(directory),seed=parameters['seed'],scenario=parameters['scenario'],
                result={key:result[key] for key in ['status','safe','requested','departed','completed',
                    'collisions','teleports','actual_end_s','mean_travel_time_s','fuel_g_per_km',
                    'all_fuel_mg','source_sha256']})


if __name__=='__main__':
    base=PACKAGE/'results'/('four_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    base.mkdir(exist_ok=False)
    manifest=json.loads((PACKAGE/'candidate_manifest.json').read_text(encoding='utf-8'))
    args=[dict(mode='transform',seed=seed,scenario=scenario,flow=1500,duration=600,max_time=900,
               output_base=base) for seed in [1,4] for scenario in ['straight3','lane_drop']]
    (base/'protocol.json').write_text(json.dumps(dict(parameters=[{k:str(v) if isinstance(v,Path) else v for k,v in a.items()} for a in args],source=manifest),indent=2)+'\n',encoding='utf-8')
    records=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        for row in pool.map(task,args):
            assert row['result']['source_sha256']==manifest['source_sha256']
            records.append(row)
            (base/'cases.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
            print(json.dumps(row),flush=True)
    assert all(hashlib.sha256((PACKAGE/name).read_bytes()).hexdigest()==value for name,value in manifest['source_sha256'].items())
    print(json.dumps(dict(output=str(base),cases=len(records),frozen_sources_unchanged=True)),flush=True)
