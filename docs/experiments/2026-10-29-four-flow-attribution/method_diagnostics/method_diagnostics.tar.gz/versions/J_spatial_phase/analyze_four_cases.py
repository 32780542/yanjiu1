"""Read-only J/H paired attribution; never writes H source or raw cases."""
from dataclasses import asdict
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

PACKAGE=Path(__file__).resolve().parent
ROOT=PACKAGE.parents[1]
MAIN=ROOT/'variants/phase5g_pure_formation'
sys.path.insert(0,str(MAIN))
from experiments.bottleneck_attribution import evaluate_case
from experiments.complete_layers import evaluate_layers

read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=read(PACKAGE/'candidate_manifest.json')
H_PACKAGE=ROOT/'tmp/head_group_H_release'
H_FREEZE=read(H_PACKAGE/'freeze.json')
assert all(sha(PACKAGE/name)==value for name,value in manifest['source_sha256'].items())
assert all(sha(MAIN/name)==sha(H_PACKAGE/name)==value for name,value in H_FREEZE['source_sha256'].items())

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);sys.modules[name]=value;spec.loader.exec_module(value)
    return value
H=module('J_static_H',H_PACKAGE/'noa/native_rules.py')
J=module('J_static_J',PACKAGE/'noa/native_rules.py')
counterexamples=[]
for a_x,b_x in [(630.,650.),(635.,645.)]:
    rows={}
    for name,rules in [('H',H),('J',J)]:
        a=rules.Vehicle(0,a_x,1.65,28.8,0);b=rules.Vehicle(1,b_x,4.95,28.8,1)
        phase=rules._physical_phase if name=='H' else lambda c,n:rules._formation_phase(c,n,1000.)
        ab=b.x+phase(b,3)-a.x-phase(a,3);ba=a.x+phase(a,2)-b.x-phase(b,2)
        rows[name]=dict(raw_A_to_B=ab,raw_B_to_A=ba,
            command_A=asdict(rules.decide(a,(b,),rules.Memory(),'transform',1000.)[0]),
            command_B=asdict(rules.decide(b,(a,),rules.Memory(),'transform',1000.)[0]))
    counterexamples.append(dict(x=[a_x,b_x],lanes=[0,1],**rows))

BASE=PACKAGE/'results/four_20261029T024738866446Z'
current=read(BASE/'cases.json')
assert len(current)==4
h_root=MAIN/'results/flow_attribution_H_final/20261029T021127615583Z'
h_records=read(h_root/'run_status.json')
pairs=[]
for case in current:
    h=next(row for row in h_records if row['flow']==1500 and row['seed']==case['seed'] and row['scenario']==case['scenario'] and row['mode']=='transform')
    paths={'H':Path(h['run_dir']),'J':Path(case['path'])}
    assert read(paths['H']/'input.json')['arrivals']==read(paths['J']/'input.json')['arrivals']
    assert read(paths['H']/'input.json')['physical']==read(paths['J']/'input.json')['physical']
    compared={}
    for name,path in paths.items():
        r=read(path/'result.json');a=evaluate_case(path)
        regions={'upstream':(3,(0,640)),'downstream':(2,(1000,1200))} if case['scenario']=='lane_drop' else {'straight':(3,(0,1200))}
        metrics={key:evaluate_layers(path/'positions.jsonl.gz',lanes,region) for key,(lanes,region) in regions.items()}
        compared[name]=dict(path=str(path),result={key:r[key] for key in ['status','safe','requested','completed','collisions','teleports','mean_travel_time_s','fuel_g_per_km']},
            attribution={key:a[key] for key in ['attribution_eligible','audit_issues','mean_segment_100_600_s','mean_segment_640_1100_s','mean_segment_800_1100_s','region_mean_n','region_mean_speed_mps','region_low_speed_fraction','flow_1000m_veh_h']},
            layers=metrics)
    equal=None
    if case['scenario']=='straight3':
        with gzip.open(paths['H']/'positions.jsonl.gz','rb') as old,gzip.open(paths['J']/'positions.jsonl.gz','rb') as new:
            while True:
                aa,bb=old.read(1024*1024),new.read(1024*1024);assert aa==bb
                if not aa:break
        equal=True
    differences={key:compared['J']['attribution'][key]-compared['H']['attribution'][key]
                 if compared['J']['attribution'][key] is not None and compared['H']['attribution'][key] is not None else None
                 for key in ['mean_segment_100_600_s','mean_segment_640_1100_s','mean_segment_800_1100_s']}
    differences['mean_travel_time_s']=compared['J']['result']['mean_travel_time_s']-compared['H']['result']['mean_travel_time_s']
    row=dict(seed=case['seed'],scenario=case['scenario'],demand_tape_equal=True,physical_parameters_equal=True,
             straight_decompressed_positions_equal=equal,H=compared['H'],J=compared['J'],J_minus_H=differences)
    pairs.append(row)
    print(json.dumps(dict(seed=row['seed'],scenario=row['scenario'],J_minus_H=differences,
                         J_result=row['J']['result'])),flush=True)

report=dict(static_counterexample_exists=True,counterexamples=counterexamples,
    method='Transform only: per-car measured x blends phase3 to phase2 across640..1000m, followed by measured-y interpolation. Each selected pair uses max(actual road lane counts)-1, including lane2 as3. Default physical_phase and H nontransform geometry unchanged.',
    manifest=manifest,main_and_H_sources_unchanged=True,
    static_tests=dict(count=9,green=str(ROOT/'results/operations/20261029T024516303860Z_J-spatial-phase-static-green_53218bff'),
                      red=str(ROOT/'results/operations/20261029T024442768862Z_J-spatial-phase-pair-weight-red_8245fd96')),
    six=read(PACKAGE/'six_summary.json'),pairs=pairs,
    full_run_log=str(ROOT/'results/operations/20261029T024738361874Z_J-four-full-cases-seeds1-4_56f572c2'),
    limitations='Static mismatch is a real counterexample, not proof that it caused all original upstream cost. Two seeds are a short round, not a complete protocol comparison. Phase field continuity does not imply all head-selection/road-count transitions are continuous. No parameter tuning, fill changes or further patches.')
with (PACKAGE/'report.json').open('x',encoding='utf-8') as out:json.dump(report,out,indent=2);out.write('\n')
print(json.dumps(dict(report=str(PACKAGE/'report.json'),cases=len(pairs),main_H_unchanged=True)),flush=True)
