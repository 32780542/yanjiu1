from dataclasses import asdict, replace
import importlib.util
from pathlib import Path
import random
import sys
import unittest

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE))
from noa import native_rules as r

spec=importlib.util.spec_from_file_location('J_H_reference',PACKAGE.parent/'head_group_H_release/noa/native_rules.py')
H=importlib.util.module_from_spec(spec);sys.modules[spec.name]=H;spec.loader.exec_module(H)


class SpatialPhaseTests(unittest.TestCase):
    def car(self,x,lane,track=0,y=None):
        return r.Vehicle(track,x,(lane+.5)*3.3 if y is None else y,28.8,lane)

    def phase(self,car,lanes,drop=1000.):
        self.assertTrue(hasattr(r,'_formation_phase'),'missing shared measured-position phase field')
        return r._formation_phase(car,lanes,drop)

    def test_two_heads_630_650_use_reciprocal_coordinates_despite_different_viewer_lanes(self):
        a,b=self.car(630,0),self.car(650,1,1)
        forward=b.x+self.phase(b,3)-a.x-self.phase(a,3)
        backward=a.x+self.phase(a,2)-b.x-self.phase(b,2)
        self.assertAlmostEqual(forward,34.583333333333336)
        self.assertAlmostEqual(backward,-forward)

    def test_635_645_counterexample_does_not_accelerate_both_heads(self):
        self.phase(self.car(635,0),3)
        a,b=self.car(635,0),self.car(645,1,1)
        ca=r.decide(a,(b,),r.Memory(),'transform',1000)[0]
        cb=r.decide(b,(a,),r.Memory(),'transform',1000)[0]
        self.assertGreater(ca.speed,r.CRUISE)
        self.assertLess(cb.speed,r.CRUISE)
        self.assertIsNone(ca.lane);self.assertIsNone(cb.lane)

    def test_unsaturated_cross_640_pair_has_equal_opposite_weighted_errors(self):
        self.phase(self.car(630,1),3)
        a,b=self.car(630,1),self.car(650,0,1)
        sa,ta,_=r._following(a,(b,),3,drop_x=1000.)
        sb,tb,_=r._following(b,(a,),2,drop_x=1000.)
        self.assertAlmostEqual(ta-a.x,65/24)
        self.assertAlmostEqual(tb-b.x,-(ta-a.x))
        self.assertLess(abs(r.POSITION_GAIN*(ta-a.x)),2.)
        self.assertAlmostEqual(sa-r.CRUISE,-(sb-r.CRUISE))
        self.assertAlmostEqual(sa-r.CRUISE,.1625)

    def test_phase_is_continuous_at_640_and_1000_for_each_lane(self):
        for boundary in [640.,1000.]:
            for lane in range(3):
                with self.subTest(x=boundary,lane=lane):
                    left=self.phase(self.car(boundary-1e-6,lane),3)
                    right=self.phase(self.car(boundary+1e-6,lane),2)
                    self.assertLess(abs(right-left),1e-5)
                    self.assertAlmostEqual(self.phase(self.car(boundary,lane),2),
                                           r._phase(lane,3 if boundary==640 else 2))

    def test_outside_transition_matches_H_three_or_two_lane_field(self):
        for x,physical_lanes in [(400.,3),(1100.,2)]:
            for y in [1.65,3.3,4.95,6.6,8.25]:
                car=self.car(x,1,y=y)
                for viewer_lanes in [2,3]:
                    self.assertAlmostEqual(self.phase(car,viewer_lanes),H._physical_phase(car,physical_lanes))

    def test_outside_pairs_keep_H_geometry_and_pair_weights(self):
        self.phase(self.car(400,0),3)
        for x,lanes in [(400.,3),(1080.,2)]:
            a,b=self.car(x,0),self.car(x+12,1,1)
            actual=r._following(a,(b,),lanes,drop_x=1000.)
            expected=H._following(H.Vehicle(**asdict(a)),(H.Vehicle(**asdict(b)),),lanes)
            self.assertEqual(actual,expected)

    def test_measured_y_interpolates_blended_center_phases_and_ignores_lane_index(self):
        for y,expected in [(1.65,7.5),(3.3,7.5),(4.95,7.5),(6.6,3.75),(8.25,0.)]:
            car=self.car(820,0,y=y)
            self.assertAlmostEqual(self.phase(car,3),expected)
            self.assertAlmostEqual(self.phase(replace(car,lane=2),2),expected)

    def test_default_physical_phase_is_unchanged(self):
        self.phase(self.car(800,1),3)
        for lanes in [2,3]:
            for y in [1.65,3.3,4.95,6.6,8.25]:
                car=self.car(820,1,y=y)
                self.assertEqual(r._physical_phase(car,lanes),H._physical_phase(car,lanes))
                self.assertEqual(self.phase(car,lanes,None),H._physical_phase(car,lanes))

    def test_formation_noa_and_straight_transform_commands_stay_H_equivalent(self):
        rng=random.Random(77)
        for mode,drop in [('formation',1000.),('noa',1000.),('transform',None)]:
            for _ in range(80):
                lane=rng.randrange(3);ego=self.car(rng.uniform(300,1100),lane)
                rows=tuple(self.car(ego.x+rng.uniform(-100,200),rng.randrange(3),i+1) for i in range(7))
                h_ego=H.Vehicle(**asdict(ego));h_rows=tuple(H.Vehicle(**asdict(c)) for c in rows)
                action,memory=r.decide(ego,rows,r.Memory(),mode,drop)
                h_action,h_memory=H.decide(h_ego,h_rows,H.Memory(),mode,drop)
                self.assertEqual((asdict(action),asdict(memory)),(asdict(h_action),asdict(h_memory)))


if __name__=='__main__':unittest.main()
