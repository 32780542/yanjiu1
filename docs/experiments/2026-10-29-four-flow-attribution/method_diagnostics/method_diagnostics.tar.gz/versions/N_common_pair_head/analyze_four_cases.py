"""Read-only short calibration: N versus frozen H and unchanged NOA controls."""
import hashlib
import json
from pathlib import Path
import sys

P=Path(__file__).resolve().parent;ROOT=P.parents[1];MAIN=ROOT/'variants/phase5g_pure_formation'
sys.path.insert(0,str(MAIN))
from experiments.bottleneck_attribution import evaluate_case
from experiments.complete_layers import evaluate_layers
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=read(P/'H_parent_freeze.json');manifest=read(P/'candidate_manifest.json')
assert all(sha(P/n)==v for n,v in manifest['source_sha256'].items())
assert all(sha(MAIN/n)==sha(ROOT/'tmp/head_group_H_release'/n)==v for n,v in freeze['source_sha256'].items())
old=read(ROOT/'tmp/J_spatial_phase/report.json')
hroot=MAIN/'results/flow_attribution_H_final/20261029T021127615583Z';hrecords=read(hroot/'run_status.json')
bases=list((P/'results').glob('four_*'));assert len(bases)==1
cases=read(bases[0]/'cases.json');assert len(cases)==4
rows=[]
for case in cases:
    seed,scenario=case['seed'],case['scenario'];path=Path(case['path'])
    h=next(row['H'] for row in old['pairs'] if row['seed']==seed and row['scenario']==scenario)
    nr=next(row for row in hrecords if row['flow']==1500 and row['seed']==seed and row['scenario']==scenario and row['mode']=='noa')
    compared={}
    for label,current_path in [('N',path),('NOA',Path(nr['run_dir']))]:
        r=read(current_path/'result.json');a=evaluate_case(current_path)
        regions={'upstream':(3,(0,640)),'downstream':(2,(1000,1200))} if scenario=='lane_drop' else {'straight':(3,(0,1200))}
        compared[label]=dict(path=str(current_path),result={k:r[k] for k in ['status','safe','requested','completed','collisions','teleports','mean_travel_time_s','fuel_g_per_km']},
            attribution={k:a[k] for k in ['attribution_eligible','audit_issues','mean_segment_100_600_s','mean_segment_640_1100_s','mean_segment_800_1100_s']},
            layers={k:evaluate_layers(current_path/'positions.jsonl.gz',lanes,region) for k,(lanes,region) in regions.items()},
            positions_sha256=sha(current_path/'positions.jsonl.gz'))
    for earlier in [h,compared['NOA']]:
        assert read(path/'input.json')['arrivals']==read(Path(earlier['path'])/'input.json')['arrivals']
        assert read(path/'input.json')['physical']==read(Path(earlier['path'])/'input.json')['physical']
    deltas={}
    for name,earlier in [('H',h),('NOA',compared['NOA'])]:
        values={k:compared['N']['attribution'][k]-earlier['attribution'][k]
                if compared['N']['attribution'][k] is not None and earlier['attribution'][k] is not None else None
                for k in ['mean_segment_100_600_s','mean_segment_640_1100_s','mean_segment_800_1100_s']}
        values['mean_travel_time_s']=(compared['N']['result']['mean_travel_time_s']-earlier['result']['mean_travel_time_s']
                                   if compared['N']['result']['mean_travel_time_s'] is not None and earlier['result']['mean_travel_time_s'] is not None else None)
        deltas['N_minus_'+name]=values
    row=dict(seed=seed,scenario=scenario,H=h,**compared,**deltas,demand_and_physical_equal=True)
    rows.append(row);print(json.dumps(dict(seed=seed,scenario=scenario,N=compared['N']['result'],**deltas)),flush=True)
did=[]
for seed in [1,4]:
    straight=next(r for r in rows if r['seed']==seed and r['scenario']=='straight3')
    drop=next(r for r in rows if r['seed']==seed and r['scenario']=='lane_drop')
    values={}
    for key in ['mean_segment_100_600_s','mean_segment_640_1100_s','mean_segment_800_1100_s']:
        a=drop['N_minus_NOA'][key];b=straight['N_minus_NOA'][key]
        values[key]=b-a if a is not None and b is not None else None
    did.append(dict(seed=seed,NOA_minus_N_drop_minus_straight=values))
report=dict(manifest=manifest,six=read(P/'six_summary.json'),pairs=rows,diagnostic_DID=did,
    mathematical_information_review='Common pair geometry and denominator are symmetric because min(xa,xb) is symmetric. The same error orders both nearest-head searches. Rear expansion reads only nearest actual same-corridor rear within50m and only when no actual front<=50; body remains the H front branch. Discrete topology/graph changes remain, and this is neither a stability proof nor a system zero-sum claim.',
    static_tests=dict(count=8,red=str(ROOT/'results/operations/20261029T031733675370Z_N-common-pair-head-static-red_36a30b71'),green=str(ROOT/'results/operations/20261029T031754649721Z_N-common-pair-head-static-green_e959d88a')),
    main_H_J_K_unmodified=True,
    limitations='Seeds1/4 are calibration only. Frozen H/NOA results are diagnostic baselines with equal demand/physical parameters, not a replacement for a same-freeze held-out full matrix. If promising, seeds6-10 with all four flows are required before method-success claims. No condition stacking, parameter search, J/K field/Jacobian or hidden intent sharing.')
with (P/'report.json').open('x',encoding='utf-8') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(dict(report=str(P/'report.json'),DID=did)),flush=True)
