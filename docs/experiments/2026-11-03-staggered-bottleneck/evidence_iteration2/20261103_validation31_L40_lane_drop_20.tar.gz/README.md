Complete preplanned road partition; no outcome-based selection.

stage/protocol.json and manifest.json are generated subset views, not replacements for the whole originals.
stage/full_protocol.json and full_manifest.json preserve the exact entire original batch bytes.
partition.json fixes the selected road and full/selected planned identities. All selected original case evidence remains exact.
Use bundled package_stage.py verify: the indexed package_tool invokes package_partition.py and audits membership too.
Selected direct flags, observed gate brackets and measured-region ledgers; original JSON/six sources exact; full positions/events NOT included.
