13 sealed cases independently verified; 3 unfinalized compute timeouts archived as metadata only. All extant partial raw files remain local, SHA/bytes indexed only. No physical completion conclusion for these 3 cases.

This archive preserves the full original 16-case protocol/manifest and every extant non-positions/events file.
The 13 sealed cases retain their complete evidence. Missing trips in unfinalized cases remain missing.
Partial raw SHA/bytes/local paths are inventory only; raw remains local, is not reconstructed or parsed here.
Return 124 and result=starting show a computation timeout, not a physical time_limit or inability to drain.
