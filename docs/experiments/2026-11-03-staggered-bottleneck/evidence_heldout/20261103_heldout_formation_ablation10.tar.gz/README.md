Self-contained selected-field SUMO stage evidence.

Selected direct flags, observed gate brackets and measured-region ledgers; original JSON/six sources exact; full positions/events NOT included.

Original protocol/manifest/case JSON are byte-exact; old absolute paths are provenance only.
index.json maps each case to a package-relative evidence directory. Runtime methods are bundled under repo/.
Verify without original repository or SUMO:
python -B repo/docs/experiments/2026-11-03-staggered-bottleneck/tools/package_stage.py verify PATH/TO/THIS.tar.gz --report verification.json

The standalone compact verifier is also inside every compact bundle. Complete positions/events are hash-indexed only.
Hashes alone cannot prove selected-field origin when the original trajectory is absent, or enable full spatial/collision re-auditing.
Unsafe, censored and incomplete attempts remain present; successful evidence verification is not performance eligibility.
