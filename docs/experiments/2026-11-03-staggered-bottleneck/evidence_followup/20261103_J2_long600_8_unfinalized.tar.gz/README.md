Full eight-case J2 plan; seven sealed cases verified, one unfinalized execution failure archived without physical metrics. Partial raw remains local, SHA/bytes indexed only.

Case and operation exit codes are preserved separately. A failed operation is not relabelled as timeout.
Missing trips remain missing; no completion, safety or travel-time values are inferred for unfinalized attempts.
