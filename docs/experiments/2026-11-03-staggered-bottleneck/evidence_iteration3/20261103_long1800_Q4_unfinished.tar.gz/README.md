Full original four-case long1800 plan; two sealed cases verified, two unfinalized compute timeouts retained without physical metrics. All extant partial raw remains local, SHA/bytes indexed only. Physical completion of timed-out cases is undetermined. Wall-clock runtimes are not performance comparisons; the operator reports active M/Q workers were temporarily lowered to BelowNormal around15:20, without changing physical inputs.

Case and operation exit codes are preserved separately. A failed operation is not relabelled as timeout.
Missing trips remain missing; no completion, safety or travel-time values are inferred for unfinalized attempts.
