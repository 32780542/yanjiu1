Complete preplanned road and fixed flow profile partition; no outcome-based selection.

stage/protocol.json and manifest.json are generated subset views, not replacements for the whole originals.
stage/full_protocol.json and full_manifest.json preserve the exact entire original batch bytes.
partition.json fixes the selected road/profile and full/selected planned identities. Low is all flows <=1500; high is all flows >=2000. All selected original case evidence remains exact.
Use bundled package_stage.py verify: the indexed package_tool invokes package_final_partition.py and audits membership too.
Selected direct flags, observed gate brackets and measured-region ledgers; original JSON/six sources exact; full positions/events NOT included.
