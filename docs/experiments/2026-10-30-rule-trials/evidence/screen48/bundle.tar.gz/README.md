Compact native-SUMO evidence; Python standard library only.

Scope: selected raw fields, full original positions local hash+rerunnable Git source.
Original input/result/trips/sumo_command JSON and all six frozen sources are
byte-exact SHA256 blobs. Complete-layer source is preserved but never executed.
flags contains ALL original frames: time_s, active_ids, aligned integer flags.
crossings contains first observed equality or consecutive-frame crossing brackets
for each vehicle at x=100,600,640,1100, linked to entire original positions.gz SHA.
Original positions/events.gz are NOT included; their full-file SHA256 and bytes
are in index.json. Offline verification checks the selected fields and recomputes
metrics. With local originals, --check-originals additionally checks full hashes
and re-extracts every selected field. Hash linkage alone cannot prove a selected
field's origin when the complete original is unavailable.

Extract compact_evidence.py from this archive and run:
python -B compact_evidence.py verify bundle.tar.gz --report verification.json
Add --check-originals only where the indexed original run directories still exist.
The script does not import project controllers, detectors, SUMO, or third parties.
