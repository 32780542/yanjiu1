def _fill_trace(ego, rows, lanes, future=False):
    """实际gap执行机会使局部车道资源计数平方和严格下降；不设全局格点。"""
    cars = tuple((c for c in _component(ego, rows) if abs(c.x - ego.x) <= 90.0))
    counts = [0] * lanes
    for car in cars:
        resource = car.lane
        if abs(car.vy) > 0.1:
            lateral = car.y / LANE_WIDTH - 0.5
            resource = max(0, min(2, ceil(lateral) if car.vy > 0 else floor(lateral)))
        if resource < lanes:
            counts[resource] += 1
    observed = (ego, *rows)
    costs, before_speeds = ({}, {})

    def cf_cached(car, snapshot, cache):
        if car.track not in cache:
            cache[car.track] = cf_speed(car, snapshot)
        return cache[car.track]

    def response_cost(car, lane):
        key = (car.track, lane)
        if key in costs:
            return costs[key]
        followers = [max((c for c in observed if c.track != car.track and c.x < car.x and _occupies(c, corridor, 0.0)), key=lambda c: (c.x, c.y, c.speed, c.vy), default=None) for corridor in (lane, car.lane)]
        moved = replace(car, lane=lane, y=(lane + 0.5) * LANE_WIDTH, vy=0.0)
        after = tuple((moved if c.track == car.track else c for c in observed))
        new_rear = followers[0]
        after_speeds = {}
        if new_rear is not None and cf_cached(new_rear, after, after_speeds) < new_rear.speed - BRAKING * 0.1 - 1e-09:
            costs[key] = None
            return None
        affected = [car]
        for follower in followers:
            if follower is not None and all((c.track != follower.track for c in affected)):
                affected.append(follower)
        cost = sum((max(0.0, cf_cached(c, observed, before_speeds) - cf_cached(moved if c.track == car.track else c, after, after_speeds)) for c in affected))
        costs[key] = cost
        return cost
    choices = []
    for car in cars:
        if car.lane >= lanes or abs(car.vy) >= 0.1:
            continue
        for lane in (car.lane - 1, car.lane + 1):
            if not 0 <= lane < lanes or 2 * (counts[lane] - counts[car.lane] + 1) >= 0:
                continue
            target, _, _ = _merge_target(car, (c for c in observed if c.track != car.track), lane)
            if abs(target - car.x) > GAP or not _clear(car, observed, lane):
                continue
            cost = response_cost(car, lane)
            if cost is not None:
                score = (cost, -car.x, abs(target - car.x), -target, -car.lane, -lane, car.y, car.speed, car.vy)
                choices.append((score, car, lane))
    if not choices:
        return dict(counts=tuple(counts), choices=choices, winner=None)
    _, car, lane = min(choices, key=lambda item: item[0])
    return dict(counts=tuple(counts), choices=choices, winner=(car, lane))
