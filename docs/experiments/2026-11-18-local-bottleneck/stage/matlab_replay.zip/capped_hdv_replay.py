import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import random
import statistics
import sys
import xml.etree.ElementTree as ET


SOURCE = Path('D:/matlab_huipu_2000/traci_tls/data')
INSTALLS = {'old': Path('C:/Program Files (x86)/DLR/Sumo'), 'modern': Path('D:/yanjiu1/SUMO/sumo-1.27.1')}
OUTPUT = Path(__file__).parent
DT = 0.1
DEMAND_STEPS = 6000
SEED = 8
PROBABILITY = 0.042


def replay(name, engine, attempt):
    output = OUTPUT / attempt / f'{engine}_{name}'
    output.mkdir(parents=True)
    sumo_home = INSTALLS[engine]
    net_file = SOURCE / 'cross.net.xml' if name == 'local' else OUTPUT / 'verified/physical_drop.net.xml'
    routes = ET.parse(SOURCE / 'cross.rou.xml')
    ordinary = routes.find("./vType[@id='CAV_HDV']")
    for entry in routes.findall('./vType'):
        if entry is not ordinary:
            routes.getroot().remove(entry)
    ordinary.set('maxSpeed', '33.3')
    ordinary.set('speedFactor', '1')
    ordinary.set('speedDev', '0')
    route_file = output / 'ordinary.rou.xml'
    routes.write(route_file, encoding='utf-8')
    sys.path.insert(0, str(sumo_home / 'tools'))
    import traci
    import traci.constants as tc

    tape_rng = random.Random(SEED)
    tape = {
        step: [lane for lane in (2, 1, 0) if tape_rng.random() < PROBABILITY]
        for step in range(1, DEMAND_STEPS + 1)
    }
    tape_bytes = json.dumps(tape, separators=(',', ':')).encode()
    tape_hash = hashlib.sha256(tape_bytes).hexdigest()
    trip_file = output / 'trip.xml'
    error_file = output / 'sumo.log'
    tape_file = output / 'demand.json'
    tape_file.write_bytes(tape_bytes)
    version = traci.start([
        str(sumo_home / 'bin/sumo.exe'), '-n', str(net_file),
        '-r', str(route_file), '--step-length', str(DT),
        '--lanechange.duration', '1', '--seed', str(SEED), '--no-step-log', 'true',
        '--tripinfo-output', str(trip_file), '--error-log', str(error_file),
    ])
    demand_by_lane = Counter()
    departed = 0
    arrived = 0
    request_lanes = {}
    arrival_at_600 = None
    state = {}
    low_speed = Counter()
    max_low_speed_count = 0
    crossing = Counter()
    native_lc_2 = []
    earliest_low_speed_m = None
    teleports = []
    collisions = []
    downstream_2 = set()
    subscribers = traci.vehicle.getSubscriptionResults if engine == 'old' else traci.vehicle.getAllSubscriptionResults
    add_vehicle = traci.vehicle.add if engine == 'old' else traci.vehicle.addLegacy
    try:
        for step in range(1, 9001):
            traci.simulationStep()
            entries = traci.simulation.getDepartedIDList()
            departed += len(entries)
            arrived += len(traci.simulation.getArrivedIDList())
            teleports.extend((step, veh_id) for veh_id in traci.simulation.getStartingTeleportIDList())
            if engine == 'modern':
                collisions.extend((step, veh_id) for veh_id in traci.simulation.getCollidingVehiclesIDList())
            for veh_id in entries:
                traci.vehicle.setLaneChangeMode(veh_id, 1621)
                traci.vehicle.subscribe(veh_id, (tc.VAR_POSITION, tc.VAR_SPEED, tc.VAR_LANE_ID))

            slow = 0
            for veh_id, values in subscribers().items():
                if tc.VAR_POSITION not in values:
                    continue
                x, _ = values[tc.VAR_POSITION]
                lane = values[tc.VAR_LANE_ID]
                speed = values[tc.VAR_SPEED]
                prev_x, prev_lane = state.get(veh_id, (0, ''))
                state[veh_id] = x, lane
                if 800 <= x < 1000 and speed < 5 and step <= DEMAND_STEPS:
                    slow += 1
                    low_speed[lane] += 1
                if step <= DEMAND_STEPS and speed < 5 and (earliest_low_speed_m is None or x < earliest_low_speed_m):
                    earliest_low_speed_m = x
                if prev_x < 1000 <= x and 1000 < step <= DEMAND_STEPS:
                    crossing[lane] += 1
                if prev_lane == 'seg1_2' and lane == 'seg1_1':
                    native_lc_2.append(round(x, 2))
                if lane == 'seg2_2':
                    downstream_2.add(veh_id)
            max_low_speed_count = max(max_low_speed_count, slow)

            for lane in tape.get(step, ()):
                veh_id = str(len(request_lanes) + 1)
                demand_by_lane[lane] += 1
                request_lanes[veh_id] = lane
                add_vehicle(veh_id, 'P1P3', -3, 0, 28.8, lane, 'CAV_HDV')
                traci.vehicle.setSpeedMode(veh_id, 31)
                traci.vehicle.setLaneChangeMode(veh_id, 0)

            if step == DEMAND_STEPS:
                arrival_at_600 = {'departed': departed, 'arrived': arrived}
            if step > DEMAND_STEPS and not traci.simulation.getMinExpectedNumber():
                break
    finally:
        traci.close()

    parsed = ET.parse(trip_file).getroot()
    trips = parsed.findall('tripinfo')
    complete_600 = [trip for trip in trips if float(trip.get('arrival')) <= 600]
    durations = [float(trip.get('duration')) for trip in trips]
    waits = [float(trip.get('departDelay')) for trip in trips]
    print(json.dumps({
        'case': name, 'engine': engine, 'sumo_version': version, 'probability_per_lane': PROBABILITY,
        'tape_sha256': tape_hash, 'requested_per_lane': demand_by_lane,
        'step_6000': arrival_at_600, 'simulated_s': round(step * DT, 1),
        'departed': departed, 'arrived': arrived, 'trip_count': len(trips),
        'completed_600_mean_duration': statistics.mean(float(trip.get('duration')) for trip in complete_600),
        'completed_mean_duration': statistics.mean(durations),
        'completed_mean_insertion_delay': statistics.mean(waits),
        'arrival_speed_max': max(float(trip.get('arrivalSpeed')) for trip in trips),
        'low_speed_vehicle_seconds': {lane: count * DT for lane, count in low_speed.items()},
        'max_low_speed_vehicle_count': max_low_speed_count,
        'min_position_of_low_speed_m': earliest_low_speed_m,
        'crossings_100_to_600_s': crossing, 'crossing_rate_100_to_600_s': sum(crossing.values()) * 7.2,
        'native_lc_2_to_1_n': len(native_lc_2),
        'native_lc_2_to_1_at_least_950m': sum(x >= 950 for x in native_lc_2),
        'native_lc_2_to_1_median_m': statistics.median(native_lc_2) if native_lc_2 else None,
        'vehicles_observed_in_seg2_2': len(downstream_2), 'teleports': teleports, 'modern_collision_implications': collisions,
    }, sort_keys=True), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('local', 'physical_drop'))
    parser.add_argument('engine', choices=INSTALLS)
    parser.add_argument('attempt')
    arguments = parser.parse_args()
    replay(arguments.case, arguments.engine, arguments.attempt)
