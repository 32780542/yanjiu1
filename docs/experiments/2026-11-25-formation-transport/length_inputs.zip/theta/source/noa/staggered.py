"""Build a balanced staggered target from one vehicle's visible segment."""
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations

from noa.transport import lane_bounds, solve_transport


# A 5 cm relative longitudinal measurement perturbation, for fixed members,
# lane observations and spacing. A common change of origin cancels.
POSITION_ERROR_M = 0.05


@dataclass(frozen=True, slots=True)
class Target:
    lane: int
    x: float
    gap: float
    certified: bool
    step_gap: float
    step_certified: bool


@lru_cache(maxsize=256)
def _tail_lanes(source, lanes, lead_phase, omitted, strict_tail):
    """Choose the occupied lanes of the last, incomplete staggered layer."""
    layers, tail = divmod(len(source) + len(omitted), lanes)
    profiles = combinations(range(lanes), tail)
    def key(extra):
        outside = sum(k % 2 == lead_phase for k in extra)
        targets = list(range(lanes)) * layers + list(extra)
        for lane in omitted:
            if lane not in targets:
                return (1, 0, 0, 0, extra)
            targets.remove(lane)
        # A three-lane tail fills the two outer positions first. Elsewhere
        # either phase can end the layer, so preserve occupied lanes first.
        return (-outside if strict_tail else 0, *lane_bounds(source, targets), -outside, extra)
    return min(profiles, key=key)


def _observed_offsets(group, lanes, spacing, head_clipped, tail_clipped):
    """Fit a locally filled lattice whose outermost sensor band may be partial."""
    anchor = group[0]
    cells = {}
    offsets = []
    for car in group:
        if car.lane >= lanes:
            return None
        phase = (anchor.lane % 2) - (car.lane % 2)
        layer = round((car.x - anchor.x) / spacing - phase / 2)
        band = 2 * layer + phase
        offset = -band * spacing / 2
        if abs(car.x + offset - anchor.x) >= spacing / 4:
            return None
        occupied = cells.setdefault(band, set())
        if car.lane in occupied:
            return None
        occupied.add(car.lane)
        offsets.append((car.lane, offset))
    low, high = min(cells), max(cells)
    if high - low < 4:
        return None
    if not head_clipped and lanes > 2 and anchor.lane % 2:
        return None
    for band in range(low + 1, high + int(not head_clipped)):
        parity = (anchor.lane - band) % 2
        if band == low + 1 and not tail_clipped and lanes != 3 and parity == 0:
            continue  # A visible, incomplete last layer may occupy only its lagging phase.
        if len(cells.get(band, ())) != len(range(parity, lanes, 2)):
            return None
    return offsets


def _balanced_offsets(group, lanes, spacing, head_clipped, tail_clipped):
    source = tuple(sorted(c.lane for c in group))
    first = min(group[0].lane, lanes - 1) % 2
    lead_phase = first if lanes == 2 else 0
    if lanes == 2 and head_clipped and abs(source.count(0) - source.count(1)) >= 2:
        lead_phase = 1 - first
    # A sensor may first intersect the second half of a layer. Remove only
    # that missing band from the template; no virtual car enters the matching.
    omitted = tuple(range(lead_phase, lanes, 2)) if head_clipped and first != lead_phase else ()
    tail = _tail_lanes(source, lanes, lead_phase, omitted, lanes == 3 and not tail_clipped)
    layers = (len(group) + len(omitted)) // lanes
    return [(lane, spacing * (layer + .5 * (lane % 2 != lead_phase)))
               for layer in range(layers + 1)
               for lane in (range(lanes) if layer < layers else tail)
               if layer or lane not in omitted]


def choose_target(rank, group, lanes, spacing, *, head_clipped=False, tail_clipped=False):
    offsets = None
    if head_clipped or tail_clipped:
        offsets = _observed_offsets(group, lanes, spacing, head_clipped, tail_clipped)
    if offsets is None:
        offsets = _balanced_offsets(group, lanes, spacing, head_clipped, tail_clipped)
    origin = sum(c.x + d for c, (_, d) in zip(group, offsets)) / len(group)
    slots = [(lane, origin - d) for lane, d in offsets]
    fit = solve_transport([(c.lane, c.x) for c in group], slots,
                          ego_index=rank, action="next_lane")
    lane, x = slots[fit.assignment[rank]]
    extent = max(d for _, d in offsets) - min(d for _, d in offsets)
    margin = 2 * len(group) * POSITION_ERROR_M * extent
    return Target(lane, x, fit.ego_gap, fit.ego_gap > margin,
                  fit.action_gap, fit.action_gap > margin)

