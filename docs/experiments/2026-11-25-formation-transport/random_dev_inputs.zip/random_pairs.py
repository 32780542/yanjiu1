"""Create a per-initial-condition comparison from random_cohorts.py's run CSV."""
import argparse
import csv
from pathlib import Path


def compare(source, output):
    with source.open(encoding="utf-8", newline="") as stream:
        runs = list(csv.DictReader(stream))
    groups = {}
    for row in runs:
        key = tuple(row[k] for k in ("road","n","spacing","seed"))
        if row["model"] in groups.setdefault(key, {}):
            raise ValueError(f"Duplicate {row['model']} for {key}")
        groups[key][row["model"]] = row
    rows = []
    for key, pair in groups.items():
        a, b = pair["base"], pair["candidate"]
        row = dict(zip(("road","n","spacing","seed"), key))
        row.update(request_sha256=a["request_sha256"], first_frame_sha256=a["first_frame_sha256"],
                   paired_full_first_frame=a["paired_full_first_frame"],
                   both_match_request=a["initial_matches_request"]==b["initial_matches_request"]=="True")
        for field in ("status","collisions","teleports","whole_both","same_ids_peak",
                      "upstream_whole_hold_s","downstream_whole_hold_s","lane_changes"):
            row["base_"+field], row["candidate_"+field] = a[field], b[field]
        row["candidate_minus_base_lane_changes"] = int(b["lane_changes"])-int(a["lane_changes"])
        for stage in ("formation","transform","observed_population"):
            for stat in ("bound_total","actual_total","excess_total","bound_max","actual_max","excess_max"):
                field = stage+"_"+stat
                row["base_"+field], row["candidate_"+field] = a[field], b[field]
            for stat in ("excess_total","excess_max"):
                field = stage+"_"+stat
                row["candidate_minus_base_"+field] = int(b[field])-int(a[field]) if a[field] and b[field] else None
        rows.append(row)
    with output.open("w",newline="",encoding="utf-8") as stream:
        writer = csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    compare(args.source,args.output)
